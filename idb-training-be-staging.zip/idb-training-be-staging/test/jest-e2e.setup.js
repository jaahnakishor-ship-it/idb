/* eslint-disable @typescript-eslint/no-require-imports */
/**
 * Runs before test files load (setupFiles). Ensures Prisma 7 client can read DATABASE_URL.
 */
if (!process.env.DATABASE_URL || !String(process.env.DATABASE_URL).trim()) {
  process.env.DATABASE_URL =
    'postgresql://postgres:postgres@127.0.0.1:5432/postgres';
}
