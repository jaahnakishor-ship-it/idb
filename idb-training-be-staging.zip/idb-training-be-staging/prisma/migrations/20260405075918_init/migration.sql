/*
  Warnings:

  - The primary key for the `Users` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `id` on the `Users` table. All the data in the column will be lost.
  - You are about to drop the `User` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `NIC` to the `Users` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "ProgramStatus" AS ENUM ('upcoming', 'ongoing', 'completed', 'cancelled');

-- CreateEnum
CREATE TYPE "ProgramType" AS ENUM ('free', 'ticketed');

-- CreateEnum
CREATE TYPE "CompletionStatus" AS ENUM ('enrolled', 'completed', 'dropped');

-- CreateEnum
CREATE TYPE "MatchMode" AS ENUM ('all', 'any');

-- AlterEnum
ALTER TYPE "District" ADD VALUE 'Kaluthara';

-- AlterTable
ALTER TABLE "Users" DROP CONSTRAINT "Users_pkey",
DROP COLUMN "id",
ADD COLUMN     "NIC" VARCHAR(12) NOT NULL,
ALTER COLUMN "password" SET DATA TYPE VARCHAR(255),
ADD CONSTRAINT "Users_pkey" PRIMARY KEY ("NIC");

-- DropTable
DROP TABLE "User";

-- DropEnum
DROP TYPE "Role";

-- CreateTable
CREATE TABLE "TrainingPrograms" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(200) NOT NULL,
    "description" VARCHAR(1000),
    "sector" VARCHAR(100) NOT NULL,
    "district" "District" NOT NULL,
    "startDate" TIMESTAMP(3) NOT NULL,
    "endDate" TIMESTAMP(3) NOT NULL,
    "status" "ProgramStatus" NOT NULL DEFAULT 'upcoming',
    "programType" "ProgramType" NOT NULL DEFAULT 'free',
    "totalBudget" DECIMAL(12,2) NOT NULL,
    "createdById" VARCHAR(12) NOT NULL,
    "rowVersion" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TrainingPrograms_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Participants" (
    "id" SERIAL NOT NULL,
    "businessName" VARCHAR(200) NOT NULL,
    "ownerName" VARCHAR(100) NOT NULL,
    "email" VARCHAR(150) NOT NULL,
    "phone" VARCHAR(15) NOT NULL,
    "district" "District" NOT NULL,
    "sector" VARCHAR(100) NOT NULL,
    "registrationNumber" VARCHAR(100) NOT NULL,
    "status" "UserStatus" NOT NULL DEFAULT 'active',
    "rowVersion" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Participants_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ProgramEnrollments" (
    "id" SERIAL NOT NULL,
    "programId" INTEGER NOT NULL,
    "participantId" INTEGER NOT NULL,
    "enrollmentDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completionStatus" "CompletionStatus" NOT NULL DEFAULT 'enrolled',
    "ticketPrice" DECIMAL(10,2),
    "rowVersion" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProgramEnrollments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiaryEvents" (
    "id" SERIAL NOT NULL,
    "title" VARCHAR(200) NOT NULL,
    "description" VARCHAR(1000),
    "eventDate" TIMESTAMP(3) NOT NULL,
    "eventTime" VARCHAR(10) NOT NULL,
    "color" VARCHAR(7) NOT NULL DEFAULT '#3B82F6',
    "createdById" VARCHAR(12) NOT NULL,
    "rowVersion" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DiaryEvents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiaryAttachments" (
    "id" SERIAL NOT NULL,
    "fileName" VARCHAR(255) NOT NULL,
    "fileUrl" VARCHAR(500) NOT NULL,
    "mimeType" VARCHAR(100) NOT NULL,
    "fileSizeKb" INTEGER NOT NULL,
    "diaryEventId" INTEGER NOT NULL,
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "DiaryAttachments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AnalyticsQueries" (
    "id" SERIAL NOT NULL,
    "filterRules" JSONB NOT NULL,
    "matchMode" "MatchMode" NOT NULL DEFAULT 'all',
    "createdById" VARCHAR(12) NOT NULL,
    "ranAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AnalyticsQueries_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Participants_email_key" ON "Participants"("email");

-- CreateIndex
CREATE UNIQUE INDEX "Participants_registrationNumber_key" ON "Participants"("registrationNumber");

-- CreateIndex
CREATE UNIQUE INDEX "ProgramEnrollments_programId_participantId_key" ON "ProgramEnrollments"("programId", "participantId");

-- AddForeignKey
ALTER TABLE "TrainingPrograms" ADD CONSTRAINT "TrainingPrograms_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "Users"("NIC") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProgramEnrollments" ADD CONSTRAINT "ProgramEnrollments_programId_fkey" FOREIGN KEY ("programId") REFERENCES "TrainingPrograms"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProgramEnrollments" ADD CONSTRAINT "ProgramEnrollments_participantId_fkey" FOREIGN KEY ("participantId") REFERENCES "Participants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiaryEvents" ADD CONSTRAINT "DiaryEvents_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "Users"("NIC") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiaryAttachments" ADD CONSTRAINT "DiaryAttachments_diaryEventId_fkey" FOREIGN KEY ("diaryEventId") REFERENCES "DiaryEvents"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AnalyticsQueries" ADD CONSTRAINT "AnalyticsQueries_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "Users"("NIC") ON DELETE RESTRICT ON UPDATE CASCADE;
