-- AlterTable
ALTER TABLE "Users" ADD COLUMN     "createdById" VARCHAR(12);

-- AlterTable
ALTER TABLE "Participants" ADD COLUMN     "createdById" VARCHAR(12);

-- AlterTable
ALTER TABLE "ProgramEnrollments" ADD COLUMN     "createdById" VARCHAR(12);

-- AlterTable
ALTER TABLE "DiaryAttachments" ADD COLUMN     "createdById" VARCHAR(12),
ADD COLUMN     "rowVersion" INTEGER NOT NULL DEFAULT 1;

-- AddForeignKey
ALTER TABLE "Users" ADD CONSTRAINT "Users_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "Users"("NIC") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Participants" ADD CONSTRAINT "Participants_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "Users"("NIC") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProgramEnrollments" ADD CONSTRAINT "ProgramEnrollments_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "Users"("NIC") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiaryAttachments" ADD CONSTRAINT "DiaryAttachments_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "Users"("NIC") ON DELETE SET NULL ON UPDATE CASCADE;
