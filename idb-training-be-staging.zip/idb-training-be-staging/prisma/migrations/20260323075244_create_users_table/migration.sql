-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('system_admin', 'epo_do', 'ma_clerk', 'ad_dd', 'hod_manager', 'board_chairman');

-- CreateEnum
CREATE TYPE "UserStatus" AS ENUM ('active', 'inactive');

-- CreateEnum
CREATE TYPE "District" AS ENUM ('Colombo', 'Gampaha', 'Kurunegala', 'Kandy', 'Matale', 'Nuwara_Eliya', 'Galle', 'Matara', 'Hambantota', 'Ampara', 'Trincomalee', 'Batticaloa', 'Mullaitivu', 'Puttalam', 'Anuradhapura', 'Polonnaruwa', 'Badulla', 'Monaragala', 'Ratnapura', 'Kegalle', 'Jaffna', 'Kilinochchi', 'Mannar', 'Vavuniya');

-- CreateTable
CREATE TABLE "Users" (
    "id" SERIAL NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "email" VARCHAR(150) NOT NULL,
    "password" VARCHAR(225) NOT NULL,
    "role" "UserRole" NOT NULL DEFAULT 'epo_do',
    "district" "District",
    "status" "UserStatus" NOT NULL DEFAULT 'active',
    "rowVersion" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Users_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Users_email_key" ON "Users"("email");
