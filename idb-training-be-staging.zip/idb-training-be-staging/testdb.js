const { Client } = require('pg');
const c = new Client({ connectionString: 'postgresql://postgres:postgres123@localhost:5432/idb_platform' });
c.connect().then(() => { console.log('Connected!'); c.end(); }).catch(e => console.error('Failed:', e.message));
