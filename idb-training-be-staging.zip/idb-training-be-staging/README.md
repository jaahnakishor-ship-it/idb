# IDB Training — backend

NestJS API for the **IDB Training & Development Analytics** platform. Persistence uses **Prisma 7** with **PostgreSQL** (`@prisma/adapter-pg`). Feature code is organized around repositories; HTTP routes are added as controllers when you wire them up.

## Requirements

- Node.js 22 (matches the Docker image; newer LTS generally works)
- PostgreSQL
- `DATABASE_URL` — PostgreSQL connection string (used by Prisma and at runtime)

## Setup

```bash
npm install
```

Generate the Prisma client (needs `DATABASE_URL` in the environment or a `.env` file at the repo root):

```bash
npx prisma generate
```

Apply migrations to your database when the schema changes:

```bash
npx prisma migrate dev
```

## Environment

Create a `.env` file in the project root (it is gitignored) with at least:

```env
DATABASE_URL="postgresql://USER:PASSWORD@HOST:PORT/DATABASE"
```

Optional:

```env
PORT=3000
```

`PrismaService` validates that `DATABASE_URL` is set when the app boots.

## Run

```bash
# development (watch)
npm run start:dev

# one-off compile + run
npm run build
npm run start

# production (compiled output)
npm run build
npm run start:prod
```

The app listens on `PORT` or **3000** by default. There is no root route; health or API routes appear once you add controllers.

## Tests

```bash
npm run test          # unit tests (src/**/*.spec.ts)
npm run test:e2e       # e2e (needs DATABASE_URL; see test/jest-e2e.setup.js)
npm run test:cov      # coverage
```

Integration-style Jest config lives under `test/jest-integration.json`. Run it explicitly:

```bash
npx jest --config ./test/jest-integration.json
```

Integration tests expect a real database; see `docs/tests/integration-testing.md`.

## Docker

```bash
docker build -t idb-training-be .
docker run --rm -e DATABASE_URL="postgresql://..." -p 3000:3000 idb-training-be
```

Ensure the image entrypoint matches your build output (`npm run start:prod` uses `dist/main.js`).

## Documentation

MkDocs site (API and backend notes) lives under `docs/`:

```bash
pip install mkdocs-material   # or your preferred MkDocs setup
mkdocs serve
```

Main references: `docs/BACKEND.md`, `docs/API_Documentation.md`, and `docs/tests/`.

## Project layout (short)

| Path | Role |
|------|------|
| `src/prisma/` | `PrismaModule`, `PrismaService` (adapter + lifecycle) |
| `src/models/` | Domain-oriented entity types |
| `src/*/` | Feature folders with `*.repository.ts` and `*.module.ts` |
| `prisma/` | `schema.prisma`, migrations |

## License

`UNLICENSED` (private); adjust in `package.json` if you publish or change terms.
