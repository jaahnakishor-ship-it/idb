import { Injectable } from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UserRepository {
  constructor(private readonly prisma: PrismaService) { }

  async findAll(where: any, skip: number, take: number) {
    const [users, total] = await this.prisma.$transaction([
      this.prisma.user.findMany({ where, skip, take }),
      this.prisma.user.count({ where }),
    ]);
    return [users, total];
  }

  async findByNic(nic: string) {
    return this.prisma.user.findUnique({
      where: { NIC: nic },
    });
  }

  async findByEmail(email: string) {
    return this.prisma.user.findUnique({
      where: { email: email },
    });
  }

  async create(data: Prisma.UserCreateInput) {
    return this.prisma.user.create({
      data,
    });
  }

  async update(nic: string, data: Prisma.UserUpdateInput) {
    return this.prisma.user.update({
      where: { NIC: nic },
      data,
    });
  }

  async delete(nic: string) {
    return this.prisma.user.delete({
      where: { NIC: nic },
    });
  }
}
