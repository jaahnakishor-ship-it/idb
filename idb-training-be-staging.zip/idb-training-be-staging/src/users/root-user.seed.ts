import { Injectable, Logger, OnApplicationBootstrap } from '@nestjs/common';
import { District, UserRole, UserStatus } from '../generated/prisma';
import { hash } from 'bcryptjs';
import { UserRepository } from './users.repository';

@Injectable()
export class RootUserSeedService implements OnApplicationBootstrap {
  private readonly logger = new Logger(RootUserSeedService.name);

  constructor(private readonly userRepository: UserRepository) {}

  async onApplicationBootstrap(): Promise<void> {
    const nic = (process.env.ROOT_USER_NIC ?? '000000000000').trim();
    const email = (process.env.ROOT_USER_EMAIL ?? 'root@idb.local').trim().toLowerCase();
    const name = (process.env.ROOT_USER_NAME ?? 'Root User').trim();
    const password = process.env.ROOT_USER_PASSWORD ?? 'ChangeMe@123';
    const district = (process.env.ROOT_USER_DISTRICT ?? 'Colombo') as District;
    const role = (process.env.ROOT_USER_ROLE ?? 'system_admin') as UserRole;
    const status = (process.env.ROOT_USER_STATUS ?? 'active') as UserStatus;

    if (!nic || !email || !name || !password) {
      this.logger.warn('Root user seed skipped due to missing required values.');
      return;
    }

    const existingByNic = await this.userRepository.findByNic(nic);
    if (existingByNic) {
      this.logger.log(`Root user already exists with NIC ${nic}; skipping seed.`);
      return;
    }

    const existingByEmail = await this.userRepository.findByEmail(email);
    if (existingByEmail) {
      this.logger.warn(`Root user seed skipped because email ${email} already exists.`);
      return;
    }

    const passwordHash = await hash(password, 12);

    await this.userRepository.create({
      NIC: nic,
      email,
      name,
      password: passwordHash,
      district,
      role,
      status,
    });

    this.logger.log(`Root user seeded successfully (NIC: ${nic}).`);
  }
}
