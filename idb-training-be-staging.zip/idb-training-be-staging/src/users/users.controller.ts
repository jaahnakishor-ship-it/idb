import { Controller, Get, Post, Body, Put, Param, Delete, Query, UseGuards, Request } from '@nestjs/common';
import { UserService } from './users.service';
import { UserRole, UserStatus, District } from '../generated/prisma';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('users')
export class UserController {
  constructor(private readonly userService: UserService) { }

  @Get()
  async findAll(@Query() query: {
    page?: number;
    limit?: number;
    search?: string;
    role?: string;
    status?: string;
    district?: string;
  }) {
    const result = await this.userService.findAll(query);
    return {
      status: 'success',
      message: 'Users retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  // must be before :nic to avoid route conflict
  @Get('me')
  async getMe(@Request() req: any) {
    const result = await this.userService.getMe(req.user.sub);
    return {
      status: 'success',
      message: 'Profile retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Get(':nic')
  async findOne(@Param('nic') nic: string) {
    const result = await this.userService.findOne(nic);
    return {
      status: 'success',
      message: 'User retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Post()
  async create(@Body() data: {
    NIC: string;
    name: string;
    email: string;
    password: string;
    role: UserRole;
    district?: District;
    status?: UserStatus;
  }) {
    const result = await this.userService.create(data);
    return {
      status: 'success',
      message: 'User created successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Put(':nic')
  async update(@Param('nic') nic: string, @Body() data: {
    name?: string;
    email?: string;
    password?: string;
    role?: UserRole;
    district?: District;
    status?: UserStatus;
    rowVersion: number;
  }) {
    const result = await this.userService.update(nic, data);
    return {
      status: 'success',
      message: 'User updated successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  // CHANGE PASSWORD
  @Put(':nic/password')
  async changePassword(@Param('nic') nic: string, @Body() data: {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
  }) {
    const result = await this.userService.changePassword(nic, data);
    return {
      status: 'success',
      message: result.message,
      timestamp: new Date().toISOString(),
      data: null,
    };
  }

  // GET NOTIFICATION PREFERENCES
  @Get(':nic/notifications')
  async getNotifications(@Param('nic') nic: string) {
    const result = await this.userService.getNotifications(nic);
    return {
      status: 'success',
      message: 'Notification preferences retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  // UPDATE NOTIFICATION PREFERENCES
  @Put(':nic/notifications')
  async updateNotifications(@Param('nic') nic: string, @Body() data: {
    emailNotifications: boolean;
    inAppNotifications: boolean;
    smsNotifications: boolean;
    rowVersion: number;
  }) {
    const result = await this.userService.updateNotifications(nic, data);
    return {
      status: 'success',
      message: 'Notification preferences updated successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Delete(':nic')
  async remove(@Param('nic') nic: string) {
    const result = await this.userService.remove(nic);
    return {
      status: 'success',
      message: result.message,
      timestamp: new Date().toISOString(),
      data: null,
    };
  }
}