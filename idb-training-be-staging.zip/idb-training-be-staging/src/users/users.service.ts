import {
  Injectable,
  NotFoundException,
  ConflictException,
  HttpException,
  HttpStatus,
  BadRequestException,
} from '@nestjs/common';
import { UserRepository } from './users.repository';
import { UserRole, UserStatus, District } from '../generated/prisma';
import * as bcrypt from 'bcryptjs';

@Injectable()
export class UserService {
  constructor(private readonly userRepository: UserRepository) { }

  // CREATE 
  async create(data: {
    NIC: string;
    name: string;
    email: string;
    password: string;
    role: UserRole;
    district?: District;
    status?: UserStatus;
  }) {
    const existingNic = await this.userRepository.findByNic(data.NIC);
    if (existingNic) {
      throw new ConflictException('A user with this NIC already exists');
    }

    const existingEmail = await this.userRepository.findByEmail(data.email);
    if (existingEmail) {
      throw new ConflictException('A user with this email already exists');
    }

    const hashedPassword = await bcrypt.hash(data.password, 10);

    const user = await this.userRepository.create({
      ...data,
      password: hashedPassword,
    });

    const { password, ...result } = user;
    return result;
  }

  // FIND ALL
  async findAll(query: {
    page?: number;
    limit?: number;
    search?: string;
    role?: string;
    status?: string;
    district?: string;
  }) {
    const page = query.page ?? 1;
    const limit = query.limit ?? 10;
    const skip = (page - 1) * limit;

    const where: any = {};

    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { email: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    if (query.role) where.role = query.role;
    if (query.status) where.status = query.status;
    if (query.district) where.district = query.district;

    const [users, total] = await this.userRepository.findAll(where, skip, limit) as [any[], number];

    return {
      data: users.map(({ password, ...user }) => user),
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  // FIND ONE
  async findOne(nic: string) {
    const user = await this.userRepository.findByNic(nic);

    if (!user) {
      throw new NotFoundException(`User with NIC ${nic} not found`);
    }

    const { password, ...result } = user;
    return result;
  }

  // GET ME (logged-in user)
  async getMe(nic: string) {
    const user = await this.userRepository.findByNic(nic);

    if (!user) {
      throw new NotFoundException('User not found');
    }

    const { password, ...result } = user;
    return result;
  }

  // UPDATE
  async update(
    nic: string,
    data: {
      name?: string;
      email?: string;
      password?: string;
      role?: UserRole;
      district?: District;
      status?: UserStatus;
      rowVersion: number;
    },
  ) {
    const existing = await this.userRepository.findByNic(nic);
    if (!existing) {
      throw new NotFoundException(`User with NIC ${nic} not found`);
    }

    if (existing.rowVersion !== data.rowVersion) {
      throw new HttpException(
        'Record has been modified by another user. Please refresh and try again.',
        HttpStatus.UNPROCESSABLE_ENTITY,
      );
    }

    if (data.password) {
      data.password = await bcrypt.hash(data.password, 10);
    }

    const updated = await this.userRepository.update(nic, {
      ...data,
      rowVersion: existing.rowVersion + 1,
    });

    const { password, ...result } = updated;
    return result;
  }

  // CHANGE PASSWORD
  async changePassword(nic: string, data: {
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
  }) {
    if (data.newPassword !== data.confirmPassword) {
      throw new BadRequestException('New password and confirm password do not match');
    }

    const user = await this.userRepository.findByNic(nic);
    if (!user) {
      throw new NotFoundException('User not found');
    }

    const isMatch = await bcrypt.compare(data.currentPassword, user.password);
    if (!isMatch) {
      throw new BadRequestException('Current password is incorrect');
    }

    const hashedPassword = await bcrypt.hash(data.newPassword, 10);

    await this.userRepository.update(nic, {
      password: hashedPassword,
      rowVersion: user.rowVersion + 1,
    });

    return { message: 'Password updated successfully' };
  }

  // GET NOTIFICATION PREFERENCES
  async getNotifications(nic: string) {
    const user = await this.userRepository.findByNic(nic);
    if (!user) {
      throw new NotFoundException('User not found');
    }

    return {
      emailNotifications: user.emailNotifications,
      inAppNotifications: user.inAppNotifications,
      smsNotifications: user.smsNotifications,
    };
  }

  // UPDATE NOTIFICATION PREFERENCES
  async updateNotifications(nic: string, data: {
    emailNotifications: boolean;
    inAppNotifications: boolean;
    smsNotifications: boolean;
    rowVersion: number;
  }) {
    const existing = await this.userRepository.findByNic(nic);
    if (!existing) {
      throw new NotFoundException('User not found');
    }

    if (existing.rowVersion !== data.rowVersion) {
      throw new HttpException(
        'Record has been modified by another user. Please refresh and try again.',
        HttpStatus.UNPROCESSABLE_ENTITY,
      );
    }

    const updated = await this.userRepository.update(nic, {
      emailNotifications: data.emailNotifications,
      inAppNotifications: data.inAppNotifications,
      smsNotifications: data.smsNotifications,
      rowVersion: existing.rowVersion + 1,
    });

    const { password, ...result } = updated;
    return result;
  }

  // DELETE
  async remove(nic: string) {
    const existing = await this.userRepository.findByNic(nic);
    if (!existing) {
      throw new NotFoundException(`User with NIC ${nic} not found`);
    }

    await this.userRepository.delete(nic);

    return { message: `User with NIC ${nic} has been deleted successfully` };
  }
}