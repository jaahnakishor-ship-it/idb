import { Controller, Get, Post, Body, Patch, Param, Delete, Query, ParseIntPipe } from '@nestjs/common';
import { ParticipantService } from './participants.service';

@Controller('participants')
export class ParticipantsController {
    constructor(private readonly participantService: ParticipantService) { }

    @Post()
    create(@Body() createParticipantDto: any) {
        return this.participantService.createParticipant(createParticipantDto);
    }

    @Get()
    findAll(
        @Query('page') page?: string,
        @Query('limit') limit?: string,
        @Query('search') search?: string,
        @Query('district') district?: string,
    ) {
        return this.participantService.getAllParticipants({
            page: page ? parseInt(page, 10) : undefined,
            limit: limit ? parseInt(limit, 10) : undefined,
            search,
            district,
        });
    }

    @Get('district/:district')
    findByDistrict(@Param('district') district: string) {
        return this.participantService.getParticipantsByDistrict(district);
    }

    @Get('search')
    search(@Query('q') q: string) {
        return this.participantService.searchParticipants(q);
    }

    @Get(':id')
    findOne(@Param('id', ParseIntPipe) id: number) {
        return this.participantService.getParticipantById(id);
    }

    @Patch(':id')
    update(@Param('id', ParseIntPipe) id: number, @Body() updateParticipantDto: any) {
        return this.participantService.updateParticipant(id, updateParticipantDto);
    }

    @Delete(':id')
    remove(@Param('id', ParseIntPipe) id: number) {
        return this.participantService.deleteParticipant(id);
    }
}
