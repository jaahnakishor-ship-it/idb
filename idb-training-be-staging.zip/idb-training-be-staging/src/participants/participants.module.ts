import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { ParticipantsRepository } from './participants.repository';
import { ParticipantService } from './participants.service';
import { ParticipantsController } from './participants.controller';

@Module({
  imports: [PrismaModule],
  controllers: [ParticipantsController],
  providers: [ParticipantsRepository, ParticipantService],
  exports: [ParticipantsRepository, ParticipantService],
})
export class ParticipantsModule { }
