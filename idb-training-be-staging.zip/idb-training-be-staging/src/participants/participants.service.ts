import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { ParticipantsRepository } from './participants.repository';

@Injectable()
export class ParticipantService {
  constructor(private participantRepo: ParticipantsRepository) { }


  async createParticipant(data: any) {

    if (data.registrationNumber) {
      const existing = await this.participantRepo.findByRegistrationNumber(data.registrationNumber);
      if (existing) {
        throw new BadRequestException('Participant with this Registration Number already exists');
      }
    }

    return this.participantRepo.create(data);
  }

  // ✅ Get All Participants (with filters)
  async getAllParticipants(params?: {
    page?: number;
    limit?: number;
    search?: string;
    district?: string;
  }) {
    const { page = 1, limit = 10, ...filters } = params || {};

    const skip = (page - 1) * limit;

    return this.participantRepo.findAll({
      skip,
      take: limit,
      ...filters,
    });
  }

  // ✅ Get Participant By ID
  async getParticipantById(id: number) {
    const participant = await this.participantRepo.findById(id);

    if (!participant) {
      throw new NotFoundException('Participant not found');
    }

    return participant;
  }

  // ✅ Update Participant
  async updateParticipant(id: number, data: any) {
    const existing = await this.participantRepo.findById(id);

    if (!existing) {
      throw new NotFoundException('Participant not found');
    }

    // Optional: Registration Number uniqueness check
    if (data.registrationNumber) {
      const duplicate = await this.participantRepo.findByRegistrationNumber(data.registrationNumber);
      if (duplicate && duplicate.id !== id) {
        throw new BadRequestException('Registration Number already in use');
      }
    }

    return this.participantRepo.update(id, data);
  }

  // ✅ Delete Participant
  async deleteParticipant(id: number) {
    const existing = await this.participantRepo.findById(id);

    if (!existing) {
      throw new NotFoundException('Participant not found');
    }

    return this.participantRepo.delete(id);
  }

  // ✅ Get Participants By District
  async getParticipantsByDistrict(district: string) {
    return this.participantRepo.findByDistrict(district);
  }

  // ✅ Search Participants
  async searchParticipants(search: string) {
    return this.participantRepo.findAll({
      search,
    });
  }
}
