import { Injectable } from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { District, UserStatus } from '../generated/prisma';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ParticipantsRepository {
  constructor(private readonly prisma: PrismaService) { }

  async findById(id: number) {
    return this.prisma.participant.findUnique({ where: { id } });
  }

  async findByRegistrationNumber(registrationNumber: string) {
    return this.prisma.participant.findUnique({
      where: { registrationNumber },
    });
  }

  async findAll(params: { skip?: number; take?: number; search?: string; district?: string }) {
    const { skip, take, search, district } = params;
    const where: Prisma.ParticipantWhereInput = {};

    if (search) {
      where.OR = [
        { businessName: { contains: search, mode: 'insensitive' } },
        { ownerName: { contains: search, mode: 'insensitive' } },
        { registrationNumber: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (district) {
      where.district = district as District;
    }

    return this.prisma.participant.findMany({
      where,
      skip,
      take,
    });
  }

  async findByFilters(filters: {
    businessName?: string;
    ownerName?: string;
    district?: District;
    sector?: string;
    status?: UserStatus;
  }) {
    return this.prisma.participant.findMany({
      where: {
        businessName: filters.businessName,
        ownerName: filters.ownerName,
        district: filters.district,
        sector: filters.sector,
        status: filters.status,
      },
    });
  }

  async create(data: Prisma.ParticipantCreateInput) {
    return this.prisma.participant.create({ data });
  }

  async update(id: number, data: Prisma.ParticipantUpdateInput) {
    return this.prisma.participant.update({
      where: { id },
      data,
    });
  }

  async findByDistrict(district: string) {
    return this.prisma.participant.findMany({
      where: { district: district as District },
    });
  }

  async delete(id: number) {
    return this.prisma.participant.delete({ where: { id } });
  }
}
