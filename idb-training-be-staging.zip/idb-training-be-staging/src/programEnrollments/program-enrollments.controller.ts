import { Controller, Get, Post, Body, Put, Param, Delete, Query, ParseIntPipe, UnprocessableEntityException } from '@nestjs/common';
import { ProgramEnrollmentsService } from './program-enrollments.service';

@Controller('enrollments')
export class ProgramEnrollmentsController {
    constructor(
        private readonly programEnrollmentsService: ProgramEnrollmentsService,
    ) { }

    private formatResponse(data: any, message: string) {
        return {
            status: true,
            message,
            timestamp: new Date().toISOString(),
            data,
        };
    }

    @Post()
    async create(@Body() createEnrollmentDto: any) {
        if (!createEnrollmentDto.programId || !createEnrollmentDto.participantId) {
            throw new UnprocessableEntityException('programId and participantId are required');
        }

        const prismaInput = {
            program: { connect: { id: Number(createEnrollmentDto.programId) } },
            participant: { connect: { id: Number(createEnrollmentDto.participantId) } },
            completionStatus: createEnrollmentDto.completionStatus || 'enrolled',
            ticketPrice: createEnrollmentDto.ticketPrice !== undefined ? Number(createEnrollmentDto.ticketPrice) : undefined,
        };
        
        try {
            const data = await this.programEnrollmentsService.create(prismaInput as any);
            return this.formatResponse(data, 'Enrollment created successfully');
        } catch (error: any) {
            if (error.code === 'P2025') {
                throw new UnprocessableEntityException('The provided Program or Participant does not exist in the database');
            }
            throw error;
        }
    }

    @Get()
    async findAll(
        @Query('page') page?: string,
        @Query('limit') limit?: string,
        @Query('programId') programId?: string,
        @Query('participantId') participantId?: string,
        @Query('completionStatus') completionStatus?: string,
    ) {
        const pageNum = page ? parseInt(page, 10) : 1;
        const limitNum = limit ? parseInt(limit, 10) : 10;
        
        const allData = await this.programEnrollmentsService.findByFilters({
            programId: programId ? parseInt(programId, 10) : undefined,
            participantId: participantId ? parseInt(participantId, 10) : undefined,
            completionStatus: completionStatus as any,
        });

        // Pagination and Meta data handled in Controller to preserve Service
        const total = allData.length;
        const skip = (pageNum - 1) * limitNum;
        const paginatedData = allData.slice(skip, skip + limitNum);

        return {
            status: true,
            message: 'Retrieved enrollments successfully',
            timestamp: new Date().toISOString(),
            data: paginatedData,
            meta: {
                total,
                page: pageNum,
                limit: limitNum,
                totalPages: Math.ceil(total / limitNum),
            }
        };
    }

    @Get('program/:programId')
    async findByProgram(
        @Param('programId', ParseIntPipe) programId: number,
    ) {
        const data = await this.programEnrollmentsService.findByProgramId(programId);
        return this.formatResponse(data, 'Retrieved enrollments for program successfully');
    }

    @Get('participant/:participantId')
    async findByParticipant(
        @Param('participantId', ParseIntPipe) participantId: number,
    ) {
        const data = await this.programEnrollmentsService.findByParticipantId(participantId);
        return this.formatResponse(data, 'Retrieved enrollments for participant successfully');
    }

    @Get(':id')
    async findOne(@Param('id', ParseIntPipe) id: number) {
        const data = await this.programEnrollmentsService.findById(id);
        return this.formatResponse(data, 'Retrieved enrollment successfully');
    }

    @Put(':id')
    async update(
        @Param('id', ParseIntPipe) id: number,
        @Body() updateEnrollmentDto: any,
    ) {
        // OCC validation in Controller to preserve Service
        const existing = await this.programEnrollmentsService.findById(id);
        if (updateEnrollmentDto.rowVersion && existing.rowVersion !== Number(updateEnrollmentDto.rowVersion)) {
            throw new UnprocessableEntityException('Record has been modified by another user. Please refresh and try again.');
        }

        const prismaUpdateInput: any = {
            rowVersion: { increment: 1 }
        };

        if (updateEnrollmentDto.programId) prismaUpdateInput.program = { connect: { id: Number(updateEnrollmentDto.programId) } };
        if (updateEnrollmentDto.participantId) prismaUpdateInput.participant = { connect: { id: Number(updateEnrollmentDto.participantId) } };
        if (updateEnrollmentDto.completionStatus) prismaUpdateInput.completionStatus = updateEnrollmentDto.completionStatus;
        if (updateEnrollmentDto.ticketPrice !== undefined) prismaUpdateInput.ticketPrice = Number(updateEnrollmentDto.ticketPrice);

        const data = await this.programEnrollmentsService.update(id, prismaUpdateInput);
        return this.formatResponse(data, 'Enrollment updated successfully');
    }

    @Delete(':id')
    async remove(@Param('id', ParseIntPipe) id: number) {
        const data = await this.programEnrollmentsService.delete(id);
        return this.formatResponse(data, 'Enrollment deleted successfully');
    }
}