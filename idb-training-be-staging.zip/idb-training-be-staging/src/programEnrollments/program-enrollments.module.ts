import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { ProgramEnrollmentsRepository } from './program-enrollments.repository';
import { ProgramEnrollmentsService } from './program-enrollments.service';
import { ProgramEnrollmentsController } from './program-enrollments.controller';

@Module({
  imports: [PrismaModule],
  controllers: [ProgramEnrollmentsController],
  providers: [ProgramEnrollmentsRepository, ProgramEnrollmentsService],
  exports: [ProgramEnrollmentsRepository, ProgramEnrollmentsService],
})
export class ProgramEnrollmentsModule { }
