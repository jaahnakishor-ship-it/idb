import { Injectable } from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { CompletionStatus } from '../generated/prisma';
import { PrismaService } from '../prisma/prisma.service';

const enrollmentWithNames = {
  select: {
    id: true,
    programId: true,
    participantId: true,
    createdById: true,
    enrollmentDate: true,
    completionStatus: true,
    ticketPrice: true,
    rowVersion: true,
    createdAt: true,
    updatedAt: true,
    participant: { select: { ownerName: true } },
    program: { select: { title: true } },
  },
} as const;

@Injectable()
export class ProgramEnrollmentsRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findById(id: number) {
    return this.prisma.programEnrollment.findUnique({
      where: { id },
      ...enrollmentWithNames,
    });
  }

  async findByProgramAndParticipant(programId: number, participantId: number) {
    return this.prisma.programEnrollment.findUnique({
      where: {
        programId_participantId: { programId, participantId },
      },
      ...enrollmentWithNames,
    });
  }

  async findByProgramId(programId: number) {
    return this.prisma.programEnrollment.findMany({
      where: { programId },
      ...enrollmentWithNames,
    });
  }

  async findByParticipantId(participantId: number) {
    return this.prisma.programEnrollment.findMany({
      where: { participantId },
      ...enrollmentWithNames,
    });
  }

  async findByFilters(filters: {
    programId?: number;
    participantId?: number;
    completionStatus?: CompletionStatus;
  }) {
    return this.prisma.programEnrollment.findMany({
      where: {
        programId: filters.programId,
        participantId: filters.participantId,
        completionStatus: filters.completionStatus,
      },
      ...enrollmentWithNames,
    });
  }

  async create(data: Prisma.ProgramEnrollmentCreateInput) {
    return this.prisma.programEnrollment.create({
      data,
      ...enrollmentWithNames,
    });
  }

  async update(id: number, data: Prisma.ProgramEnrollmentUpdateInput) {
    return this.prisma.programEnrollment.update({
      where: { id },
      data,
      ...enrollmentWithNames,
    });
  }

  async delete(id: number) {
    return this.prisma.programEnrollment.delete({
      where: { id },
      ...enrollmentWithNames,
    });
  }
}
