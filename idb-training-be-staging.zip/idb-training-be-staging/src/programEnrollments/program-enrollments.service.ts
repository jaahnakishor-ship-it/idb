import {
  Injectable,
  NotFoundException,
  ConflictException,
} from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { CompletionStatus } from '../generated/prisma';
import { ProgramEnrollmentsRepository } from './program-enrollments.repository';
import { ProgramEnrollmentEntity } from '../models/program-enrollment.entity';

@Injectable()
export class ProgramEnrollmentsService {
  constructor(
    private readonly programEnrollmentsRepository: ProgramEnrollmentsRepository,
  ) { }

  private toEntity(
    data: {
      id: number;
      programId: number;
      participantId: number;
      createdById?: string | null;
      enrollmentDate: Date;
      completionStatus: CompletionStatus;
      ticketPrice: unknown;
      rowVersion: number;
      createdAt: Date;
      updatedAt: Date;
      participant?: { ownerName: string };
      program?: { title: string };
    },
  ): ProgramEnrollmentEntity {
    const {
      participant,
      program,
      ticketPrice,
      createdById,
      ...enrollment
    } = data;

    return {
      ...enrollment,
      createdById: createdById ?? undefined,
      participantName: participant?.ownerName ?? '',
      programName: program?.title ?? '',
      ticketPrice:
        ticketPrice != null ? Number(ticketPrice) : null,
    };
  }


  async findById(
    id: number,
  ): Promise<ProgramEnrollmentEntity> {
    const enrollment =
      await this.programEnrollmentsRepository.findById(id);

    if (!enrollment) {
      throw new NotFoundException(
        `ProgramEnrollment with id ${id} not found`,
      );
    }

    return this.toEntity(enrollment); // ✅
  }


  async findByProgramAndParticipant(
    programId: number,
    participantId: number,
  ): Promise<ProgramEnrollmentEntity> {
    const enrollment =
      await this.programEnrollmentsRepository.findByProgramAndParticipant(
        programId,
        participantId,
      );

    if (!enrollment) {
      throw new NotFoundException(
        `Enrollment not found for programId ${programId} ` +
        `and participantId ${participantId}`,
      );
    }

    return this.toEntity(enrollment);
  }


  async findByProgramId(
    programId: number,
  ): Promise<ProgramEnrollmentEntity[]> {
    const enrollments =
      await this.programEnrollmentsRepository.findByProgramId(programId);

    return enrollments.map((e) => this.toEntity(e)); // ✅
  }


  async findByParticipantId(
    participantId: number,
  ): Promise<ProgramEnrollmentEntity[]> {
    const enrollments =
      await this.programEnrollmentsRepository.findByParticipantId(participantId);

    return enrollments.map((e) => this.toEntity(e)); // ✅
  }


  async findByFilters(filters: {
    programId?: number;
    participantId?: number;
    completionStatus?: CompletionStatus;
  }): Promise<ProgramEnrollmentEntity[]> {
    const enrollments =
      await this.programEnrollmentsRepository.findByFilters(filters);

    return enrollments.map((e) => this.toEntity(e)); // ✅
  }


  async create(
    programId: number,
    participantId: number,
    enrollmentData: Prisma.ProgramEnrollmentCreateInput,
  ): Promise<ProgramEnrollmentEntity> {
    // Check for duplicate enrollment
    const existing =
      await this.programEnrollmentsRepository.findByProgramAndParticipant(
        programId,
        participantId,
      );
    if (existing) {
      throw new ConflictException(
        `Participant ${participantId} is already enrolled in program ${programId}`,
      );
    }

    const created = await this.programEnrollmentsRepository.create(
      enrollmentData,
    );

    return this.toEntity(created);
  }


  async update(
    id: number,
    updateData: Prisma.ProgramEnrollmentUpdateInput,
  ): Promise<ProgramEnrollmentEntity> {
    const updated =
      await this.programEnrollmentsRepository.update(id, updateData);

    return this.toEntity(updated);
  }


  async updateMultiple(
    ids: number[],
    updateData: Prisma.ProgramEnrollmentUpdateInput,
  ): Promise<ProgramEnrollmentEntity[]> {
    const updated = await Promise.all(
      ids.map((id) => this.programEnrollmentsRepository.update(id, updateData)),
    );

    return updated.map((e) => this.toEntity(e)); // ✅
  }


  async delete(id: number): Promise<ProgramEnrollmentEntity> {
    const deleted = await this.programEnrollmentsRepository.delete(id);

    return this.toEntity(deleted); // ✅
  }
}
