import { Injectable } from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DiaryAttachmentsRepository {
  constructor(private readonly prisma: PrismaService) { }

  async findById(id: number) {
    return this.prisma.diaryAttachment.findUnique({ where: { id } });
  }

  async findByDiaryEventId(diaryEventId: number) {
    return this.prisma.diaryAttachment.findMany({
      where: { diaryEventId },
      orderBy: { uploadedAt: 'desc' },
    });
  }

  async create(data: Prisma.DiaryAttachmentCreateInput) {
    return this.prisma.diaryAttachment.create({ data });
  }

  async update(id: number, data: Prisma.DiaryAttachmentUpdateInput) {
    return this.prisma.diaryAttachment.update({
      where: { id },
      data,
    });
  }

  async delete(id: number) {
    return this.prisma.diaryAttachment.delete({ where: { id } });
  }
}
