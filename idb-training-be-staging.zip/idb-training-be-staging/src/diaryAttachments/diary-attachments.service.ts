import {
    Injectable,
    NotFoundException,
    BadRequestException,
} from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { DiaryAttachmentsRepository } from './diary-attachments.repository';
import { DiaryAttachmentEntity } from '../models/diary-attachment.entity';
import * as fs from 'fs';
import * as path from 'path';
 
@Injectable()
export class DiaryAttachmentsService {
 
    // Allowed file types
    private readonly ALLOWED_MIME_TYPES = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'image/gif',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];
 
    // Max file size 5MB
    private readonly MAX_FILE_SIZE_KB = 5120;
 
    constructor(
        private readonly diaryAttachmentsRepository: DiaryAttachmentsRepository,
    ) { }
 
    // helper mapper
    private toEntity(data: any): DiaryAttachmentEntity {
        return {
            ...data,
            createdById: data.createdById ?? undefined,
        };
    }
 
    // Upload file and save to database
    async uploadAttachment(
        diaryEventId: number,
        file: any,
        createdById: string,
    ): Promise<DiaryAttachmentEntity> {
 
        // File type validation
        if (!this.ALLOWED_MIME_TYPES.includes(file.mimetype)) {
            throw new BadRequestException(
                `File type '${file.mimetype}' is not allowed. ` +
                `Allowed types: PDF, JPG, PNG, DOC, DOCX, XLS, XLSX`,
            );
        }
 
        // File size validation
        const fileSizeKb = Math.round(file.size / 1024);
        if (fileSizeKb > this.MAX_FILE_SIZE_KB) {
            throw new BadRequestException(
                `File size ${fileSizeKb}KB exceeds maximum allowed size of ${this.MAX_FILE_SIZE_KB}KB (5MB)`,
            );
        }
 
        const createData = {
            fileName: file.originalname,
            fileUrl: file.path,
            mimeType: file.mimetype,
            fileSizeKb,
            diaryEvent: {
                connect: { id: diaryEventId },
            },
        } as any;

        if (createdById) {
            createData.createdBy = { connect: { NIC: createdById } };
        }

        const result = await this.diaryAttachmentsRepository.create(createData);
 
        return this.toEntity(result);
    }

    // Update attachment
    async updateAttachment(
        id: number,
        file: any,
        createdById: string,
    ): Promise<DiaryAttachmentEntity> {
        // File type validation
        if (!this.ALLOWED_MIME_TYPES.includes(file.mimetype)) {
            throw new BadRequestException(
                `File type '${file.mimetype}' is not allowed. ` +
                `Allowed types: PDF, JPG, PNG, DOC, DOCX, XLS, XLSX`,
            );
        }

        // File size validation
        const fileSizeKb = Math.round(file.size / 1024);
        if (fileSizeKb > this.MAX_FILE_SIZE_KB) {
            throw new BadRequestException(
                `File size ${fileSizeKb}KB exceeds maximum allowed size of ${this.MAX_FILE_SIZE_KB}KB (5MB)`,
            );
        }

        const result = await this.diaryAttachmentsRepository.update(
            id,
            {
                fileName: file.originalname,
                fileUrl: file.path,
                mimeType: file.mimetype,
                fileSizeKb,
                createdBy: createdById
                    ? { connect: { NIC: createdById } }
                    : undefined,
            } as any,
        );

        return this.toEntity(result);
    }

    // Delete attachment
    async deleteAttachment(id: number): Promise<void> {
        const attachment = await this.diaryAttachmentsRepository.findById(id);
        if (!attachment) {
            throw new NotFoundException(`Attachment with id ${id} not found`);
        }

        // Delete from filesystem if exists
        if (attachment.fileUrl) {
            try {
                if (fs.existsSync(attachment.fileUrl)) {
                    fs.unlinkSync(attachment.fileUrl);
                }
            } catch (error) {
                console.error(`Failed to delete file: ${attachment.fileUrl}`, error);
            }
        }

        // Delete from database
        await this.diaryAttachmentsRepository.delete(id);
    }

    // Get attachment by id
    async getAttachmentById(id: number): Promise<DiaryAttachmentEntity> {
        const attachment = await this.diaryAttachmentsRepository.findById(id);
        if (!attachment) {
            throw new NotFoundException(`Attachment with id ${id} not found`);
        }
        return this.toEntity(attachment);
    }

    // Get attachments by diary event
    async getAttachmentsByDiaryEvent(
        diaryEventId: number,
    ): Promise<DiaryAttachmentEntity[]> {
        const attachments =
            await this.diaryAttachmentsRepository.findByDiaryEventId(diaryEventId);
        return attachments.map((a) => this.toEntity(a));
    }
}
