import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { DiaryAttachmentsRepository } from './diary-attachments.repository';
import { DiaryAttachmentsService } from './diary-attachments.service';
import { DiaryAttachmentsController } from './diary-attachments.controller';

@Module({
  imports: [PrismaModule],
  controllers: [DiaryAttachmentsController],
  providers: [DiaryAttachmentsRepository, DiaryAttachmentsService],
  exports: [DiaryAttachmentsRepository, DiaryAttachmentsService],
})
export class DiaryAttachmentsModule { }
