import {
    Controller,
    Get,
    Post,
    Put,
    Delete,
    Param,
    Body,
    Query,
    UploadedFile,
    UseInterceptors,
    BadRequestException,
    ParseIntPipe,
} from '@nestjs/common';

import type { Prisma } from '../generated/prisma';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';
import * as fs from 'fs';

import { DiaryAttachmentsService } from './diary-attachments.service';

@Controller('diary-events/:eventId/attachments')
export class DiaryAttachmentsController {
    constructor(private readonly diaryAttachmentsService: DiaryAttachmentsService) { }

    @Post()
    @UseInterceptors(
        FileInterceptor('file', {
            storage: diskStorage({
                destination: (req, file, cb) => {
                    const uploadPath = './uploads';
                    if (!fs.existsSync(uploadPath)) {
                        fs.mkdirSync(uploadPath, { recursive: true });
                    }
                    cb(null, uploadPath);
                },
                filename: (req, file, callback) => {
                    const fileName =
                        Date.now() + '-' + Math.round(Math.random() * 1000000000);
                    callback(null, fileName + extname(file.originalname));
                },
            }),
            limits: { fileSize: 5 * 1024 * 1024 },
        }),
    )
    create(
        @Param('eventId', ParseIntPipe) eventId: number,
        @UploadedFile() file: any,
    ) {
        if (!file) {
            throw new BadRequestException('No file uploaded');
        }

        const allowedTypes = /jpeg|jpg|png|pdf|doc|docx|xls|xlsx/;
        if (!allowedTypes.test(extname(file.originalname).toLowerCase())) {
            throw new BadRequestException('File type not allowed');
        }

        return this.diaryAttachmentsService.uploadAttachment(eventId, file, 'system');
    }

    @Get()
    findAll(
        @Param('eventId', ParseIntPipe) eventId: number,
        @Query('page') page?: string,
        @Query('limit') limit?: string,
    ) {
        return this.diaryAttachmentsService.getAttachmentsByEventId(eventId, {
            page: page ? parseInt(page, 10) : undefined,
            limit: limit ? parseInt(limit, 10) : undefined,
        });
    }

    @Get(':id')
    findOne(@Param('id', ParseIntPipe) id: number) {
        return this.diaryAttachmentsService.getAttachmentById(id);
    }

    @Put(':id')
    update(
        @Param('id', ParseIntPipe) id: number,
        @Body() updateDto: Prisma.DiaryAttachmentUpdateInput,
    ) {
        return this.diaryAttachmentsService.updateAttachment(id, updateDto);
    }

    @Delete(':id')
    remove(@Param('id', ParseIntPipe) id: number) {
        return this.diaryAttachmentsService.deleteAttachment(id);
    }
}