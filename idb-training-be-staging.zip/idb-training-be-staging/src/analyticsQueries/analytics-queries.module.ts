import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { AnalyticsQueriesRepository } from './analytics-queries.repository';
import { AnalyticsQueriesService } from './analytics-queries.service';
import { AnalyticsQueriesController } from './analytics-queries.controller';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    PrismaModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET ?? 'changeme',
      signOptions: { expiresIn: '7d' },
    }),
  ],
  controllers: [AnalyticsQueriesController],
  providers: [AnalyticsQueriesRepository, AnalyticsQueriesService],
  exports: [AnalyticsQueriesRepository, AnalyticsQueriesService],
})
export class AnalyticsQueriesModule {}