import { Injectable, NotFoundException } from '@nestjs/common';
import { AnalyticsQueriesRepository } from './analytics-queries.repository';
import { Prisma, MatchMode } from '../generated/prisma';

@Injectable()
export class AnalyticsQueriesService {
  constructor(private readonly analyticsQueriesRepository: AnalyticsQueriesRepository) {}

  async create(data: Prisma.AnalyticsQueryCreateInput) {
    return this.analyticsQueriesRepository.create(data);
  }

  async findAll(filters: { createdById?: string; matchMode?: MatchMode }) {
    return this.analyticsQueriesRepository.findByFilters(filters);
  }

  async findByUser(createdById: string) {
    return this.analyticsQueriesRepository.findByCreatedById(createdById);
  }

  async findOne(id: number) {
    const query = await this.analyticsQueriesRepository.findById(id);
    if (!query) {
      throw new NotFoundException(`Analytics query with ID ${id} not found`);
    }
    return query;
  }

  async update(id: number, data: Prisma.AnalyticsQueryUpdateInput) {
    await this.findOne(id);
    return this.analyticsQueriesRepository.update(id, data);
  }

  async remove(id: number) {
    await this.findOne(id);
    return this.analyticsQueriesRepository.delete(id);
  }

  // DASHBOARD SUMMARY
  async getDashboardSummary() {
    return this.analyticsQueriesRepository.getDashboardStats();
  }

  // RUN QUERY
  async runQuery(data: {
    filterRules: any[];
    matchMode: 'all' | 'any';
    createdById: string;
  }) {
    // Save the query for history
    await this.analyticsQueriesRepository.create({
      filterRules: data.filterRules,
      matchMode: data.matchMode === 'all' ? MatchMode.all : MatchMode.any,
      createdBy: { connect: { NIC: data.createdById } },
    });

    // Execute against participants
    const results = await this.analyticsQueriesRepository.runParticipantQuery(
      data.filterRules,
      data.matchMode,
    );

    return {
      count: results.length,
      results,
    };
  }
}