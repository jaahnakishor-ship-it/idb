import { Injectable } from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { MatchMode } from '../generated/prisma';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AnalyticsQueriesRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findById(id: number) {
    return this.prisma.analyticsQuery.findUnique({ where: { id } });
  }

  async findByCreatedById(createdById: string) {
    return this.prisma.analyticsQuery.findMany({
      where: { createdById },
      orderBy: { ranAt: 'desc' },
    });
  }

  async findByFilters(filters: { createdById?: string; matchMode?: MatchMode }) {
    return this.prisma.analyticsQuery.findMany({
      where: {
        createdById: filters.createdById,
        matchMode: filters.matchMode,
      },
      orderBy: { ranAt: 'desc' },
    });
  }

  async create(data: Prisma.AnalyticsQueryCreateInput) {
    return this.prisma.analyticsQuery.create({ data });
  }

  async update(id: number, data: Prisma.AnalyticsQueryUpdateInput) {
    return this.prisma.analyticsQuery.update({
      where: { id },
      data,
    });
  }

  async delete(id: number) {
    return this.prisma.analyticsQuery.delete({ where: { id } });
  }

  // DASHBOARD STATS
  async getDashboardStats() {
    const [
      totalPrograms,
      activePrograms,
      totalParticipants,
      totalUsers,
      totalEnrollments,
      completedEnrollments,
    ] = await this.prisma.$transaction([
      this.prisma.trainingProgram.count(),
      this.prisma.trainingProgram.count({ where: { status: 'ongoing' } }),
      this.prisma.participant.count(),
      this.prisma.user.count({ where: { status: 'active' } }),
      this.prisma.programEnrollment.count(),
      this.prisma.programEnrollment.count({ where: { completionStatus: 'completed' } }),
    ]);

    const successRate = totalEnrollments > 0
      ? Math.round((completedEnrollments / totalEnrollments) * 100)
      : 0;

    return {
      activeProjects: activePrograms,
      totalPrograms,
      teamMembers: totalUsers,
      totalParticipants,
      tasksCompleted: completedEnrollments,
      totalEnrollments,
      successRate,
    };
  }

  // RUN PARTICIPANT QUERY
  async runParticipantQuery(rules: any[], matchMode: 'all' | 'any') {
    const conditions = rules.map((rule: any) => {
      const { field, value, not } = rule;

      let condition: any = {};

      switch (field) {
        case 'businessName':
        case 'ownerName':
          condition = { [field]: { contains: value, mode: 'insensitive' } };
          break;
        case 'email':
          condition = { email: { contains: value, mode: 'insensitive' } };
          break;
        case 'district':
          condition = { district: value };
          break;
        case 'sector':
          condition = { sector: { contains: value, mode: 'insensitive' } };
          break;
        case 'status':
          condition = { status: value };
          break;
        default:
          condition = {};
      }

      return not ? { NOT: condition } : condition;
    });

    const where = matchMode === 'all'
      ? { AND: conditions }
      : { OR: conditions };

    return this.prisma.participant.findMany({ where });
  }
}