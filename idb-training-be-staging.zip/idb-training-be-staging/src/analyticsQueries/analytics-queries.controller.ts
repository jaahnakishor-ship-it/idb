import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Param,
  Body,
  Query,
  ParseIntPipe,
  UseGuards,
  Request,
} from '@nestjs/common';
import { AnalyticsQueriesService } from './analytics-queries.service';
import { MatchMode } from '../generated/prisma';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('analytics-queries')
export class AnalyticsQueriesController {
  constructor(private readonly analyticsQueriesService: AnalyticsQueriesService) {}

  // DASHBOARD SUMMARY — must be before :id routes
  @Get('dashboard')
  async getDashboard() {
    const result = await this.analyticsQueriesService.getDashboardSummary();
    return {
      status: 'success',
      message: 'Dashboard summary retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  // RUN QUERY
  @Post('run')
  async runQuery(@Body() body: any, @Request() req: any) {
    const result = await this.analyticsQueriesService.runQuery({
      filterRules: body.filterRules,
      matchMode: body.matchMode ?? 'all',
      createdById: req.user.sub,
    });
    return {
      status: 'success',
      message: 'Query executed successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Post()
  async create(@Body() createDto: any) {
    const result = await this.analyticsQueriesService.create(createDto);
    return {
      status: 'success',
      message: 'Analytics query created successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Get()
  async findAll(
    @Query('createdById') createdById?: string,
    @Query('matchMode') matchMode?: MatchMode,
  ) {
    const result = await this.analyticsQueriesService.findAll({ createdById, matchMode });
    return {
      status: 'success',
      message: 'Analytics queries retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Get('user/:createdById')
  async findByUser(@Param('createdById') createdById: string) {
    const result = await this.analyticsQueriesService.findByUser(createdById);
    return {
      status: 'success',
      message: 'User analytics queries retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
    const result = await this.analyticsQueriesService.findOne(id);
    return {
      status: 'success',
      message: 'Analytics query retrieved successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Put(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateDto: any,
  ) {
    const result = await this.analyticsQueriesService.update(id, updateDto);
    return {
      status: 'success',
      message: 'Analytics query updated successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }

  @Delete(':id')
  async remove(@Param('id', ParseIntPipe) id: number) {
    const result = await this.analyticsQueriesService.remove(id);
    return {
      status: 'success',
      message: 'Analytics query deleted successfully',
      timestamp: new Date().toISOString(),
      data: result,
    };
  }
}