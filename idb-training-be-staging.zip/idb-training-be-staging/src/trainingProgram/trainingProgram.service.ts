import {
  Injectable,
  NotFoundException,
  ConflictException,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { TrainingProgramsRepository } from './trainingProgram.repository';
import { District, ProgramStatus, ProgramType } from '../generated/prisma';

@Injectable()
export class TrainingProgramsService {
  constructor(private readonly trainingProgramsRepository: TrainingProgramsRepository) { }

  // CREATE
  async create(data: {
    title: string;
    description?: string;
    sector: string;
    district: District;
    startDate: Date;
    endDate: Date;
    status?: ProgramStatus;
    programType?: ProgramType;
    totalBudget: number;
    createdById: string;
  }) {
    // Save to database
    const { createdById, ...rest } = data;
    const program = await this.trainingProgramsRepository.create({
      ...rest,
      createdBy: {
        connect: { NIC: createdById }
      }
    });

    return program;
  }

  // FIND ALL
  async findAll(query: {
    page?: number;
    limit?: number;
    search?: string;
    district?: District;
    status?: ProgramStatus;
    programType?: ProgramType;
  }) {
    // Set defaults
    const page = query.page ?? 1;
    const limit = query.limit ?? 10;

    // Build filters
    const filters: any = {};

    if (query.search) {
      filters.title = query.search;
    }

    if (query.district) filters.district = query.district;
    if (query.status) filters.status = query.status;
    if (query.programType) filters.programType = query.programType;

    // Query database
    const programs = await this.trainingProgramsRepository.findByFilters(filters);

    // Return with pagination metadata
    const total = programs.length;
    const paginatedData = programs.slice((page - 1) * limit, page * limit);

    return {
      data: paginatedData,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  // FIND ONE
  async findOne(id: number) {
    const program = await this.trainingProgramsRepository.findById(id);

    if (!program) {
      throw new NotFoundException(`Training program with ID ${id} not found`);
    }

    return program;
  }

  // UPDATE
  async update(
    id: number,
    data: {
      title?: string;
      description?: string;
      sector?: string;
      district?: District;
      startDate?: Date;
      endDate?: Date;
      status?: ProgramStatus;
      programType?: ProgramType;
      totalBudget?: number;
      rowVersion: number; // required for conflict check
    },
  ) {
    // Check program exists
    const existing = await this.trainingProgramsRepository.findById(id);
    if (!existing) {
      throw new NotFoundException(`Training program with ID ${id} not found`);
    }

    // Check rowVersion matches — optimistic concurrency control
    if (existing.rowVersion !== data.rowVersion) {
      throw new HttpException(
        'Record has been modified by another user. Please refresh and try again.',
        HttpStatus.UNPROCESSABLE_ENTITY,
      );
    }

    // Update in database
    const updated = await this.trainingProgramsRepository.update(id, {
      ...data,
      rowVersion: existing.rowVersion + 1,
    });

    return updated;
  }

  // DELETE
  async remove(id: number) {
    // Check program exists first
    const existing = await this.trainingProgramsRepository.findById(id);
    if (!existing) {
      throw new NotFoundException(`Training program with ID ${id} not found`);
    }

    await this.trainingProgramsRepository.delete(id);

    return { message: `Training program with ID ${id} has been deleted successfully` };
  }
}