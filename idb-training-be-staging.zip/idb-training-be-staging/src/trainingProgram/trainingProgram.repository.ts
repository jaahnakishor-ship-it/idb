import { Injectable } from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { District, ProgramStatus, ProgramType } from '../generated/prisma';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class TrainingProgramsRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findById(id: number) {
    return this.prisma.trainingProgram.findUnique({ where: { id } });
  }

  async findByFilters(filters: {
    title?: string;
    sector?: string;
    district?: District;
    status?: ProgramStatus;
    programType?: ProgramType;
    createdById?: string;
  }) {
    return this.prisma.trainingProgram.findMany({
      where: {
        title: filters.title,
        sector: filters.sector,
        district: filters.district,
        status: filters.status,
        programType: filters.programType,
        createdById: filters.createdById,
      },
    });
  }

  async create(data: Prisma.TrainingProgramCreateInput) {
    return this.prisma.trainingProgram.create({ data });
  }

  async update(id: number, data: Prisma.TrainingProgramUpdateInput) {
    return this.prisma.trainingProgram.update({
      where: { id },
      data,
    });
  }

  async delete(id: number) {
    return this.prisma.trainingProgram.delete({ where: { id } });
  }
}
