import {
    Controller,
    Get,
    Post,
    Put,
    Delete,
    Param,
    Body,
    Query,
    ParseIntPipe,
    HttpCode,
    HttpStatus,
} from '@nestjs/common';
import { TrainingProgramsService } from './trainingProgram.service';
import { District, ProgramStatus, ProgramType } from '../generated/prisma';

@Controller('training-programs')
export class TrainingProgramsController {
    constructor(private readonly trainingProgramsService: TrainingProgramsService) { }

    // ─── CREATE ───────────────────────────────────────────────────────────────

    @Post()
    async create(
        @Body()
        body: {
            title: string;
            description?: string;
            sector: string;
            district: District;
            startDate: Date;
            endDate: Date;
            status?: ProgramStatus;
            programType?: ProgramType;
            totalBudget: number;
            createdById: string;
        },
    ) {
        return this.trainingProgramsService.create(body);
    }

    // ─── FIND ALL ─────────────────────────────────────────────────────────────

    @Get()
    async findAll(
        @Query('page') page?: string,
        @Query('limit') limit?: string,
        @Query('search') search?: string,
        @Query('district') district?: District,
        @Query('status') status?: ProgramStatus,
        @Query('programType') programType?: ProgramType,
    ) {
        return this.trainingProgramsService.findAll({
            page: page ? Number(page) : undefined,
            limit: limit ? Number(limit) : undefined,
            search,
            district,
            status,
            programType,
        });
    }

    // ─── FIND ONE ─────────────────────────────────────────────────────────────

    @Get(':id')
    async findOne(@Param('id', ParseIntPipe) id: number) {
        return this.trainingProgramsService.findOne(id);
    }

    // ─── UPDATE ───────────────────────────────────────────────────────────────

    @Put(':id')
    async update(
        @Param('id', ParseIntPipe) id: number,
        @Body()
        body: {
            title?: string;
            description?: string;
            sector?: string;
            district?: District;
            startDate?: Date;
            endDate?: Date;
            status?: ProgramStatus;
            programType?: ProgramType;
            totalBudget?: number;
            rowVersion: number;
        },
    ) {
        return this.trainingProgramsService.update(id, body);
    }

    // ─── DELETE ───────────────────────────────────────────────────────────────

    @Delete(':id')
    @HttpCode(HttpStatus.OK)
    async remove(@Param('id', ParseIntPipe) id: number) {
        return this.trainingProgramsService.remove(id);
    }
}