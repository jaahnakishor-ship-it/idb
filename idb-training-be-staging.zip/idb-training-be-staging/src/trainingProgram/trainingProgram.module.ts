import { Module } from '@nestjs/common';
import { TrainingProgramsRepository } from './trainingProgram.repository';
import { PrismaModule } from '../prisma/prisma.module';
import { TrainingProgramsService } from './trainingProgram.service';
import { TrainingProgramsController } from './trainingProgram.controller';

@Module({
  imports: [PrismaModule],
  controllers: [TrainingProgramsController],
  providers: [TrainingProgramsRepository, TrainingProgramsService],
  exports: [TrainingProgramsRepository, TrainingProgramsService],
})
export class TrainingProgramsModule { }
