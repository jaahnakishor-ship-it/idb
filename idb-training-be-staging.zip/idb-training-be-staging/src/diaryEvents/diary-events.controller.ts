import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  ParseIntPipe,
  HttpCode,
  HttpStatus,
  UseGuards,
} from '@nestjs/common';
import { DiaryEventsService } from './dairy-events.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

class CreateDiaryEventDto {
  title!: string;
  description?: string;
  eventDate!: Date;
  eventTime!: string;
  color?: string;
  createdById!: string;
}

class UpdateDiaryEventDto {
  title?: string;
  description?: string;
  eventDate?: Date;
  eventTime?: string;
  color?: string;
  rowVersion!: number;
}

@UseGuards(JwtAuthGuard)
@Controller('diary-events')
export class DiaryEventsController {
  constructor(private readonly diaryEventsService: DiaryEventsService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createDto: CreateDiaryEventDto) {
    return this.diaryEventsService.create(createDto);
  }

  @Get('user/:createdById')
  async findByUser(@Param('createdById') createdById: string) {
    return this.diaryEventsService.findByUser(createdById);
  }

  @Get('search')
  async findByFilters(
    @Query('title') title?: string,
    @Query('createdById') createdById?: string,
  ) {
    return this.diaryEventsService.findByFilters({ title, createdById });
  }

  @Get(':id')
  async findOne(@Param('id', ParseIntPipe) id: number) {
    return this.diaryEventsService.findOne(id);
  }

  @Put(':id')
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateDto: UpdateDiaryEventDto,
  ) {
    return this.diaryEventsService.update(id, updateDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  async remove(@Param('id', ParseIntPipe) id: number) {
    return this.diaryEventsService.remove(id);
  }
}
