import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';
import { DiaryEventsRepository } from './diary-events.repository';
import { DiaryEventsService } from './dairy-events.service';
import { DiaryEventsController } from './diary-events.controller';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    PrismaModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET ?? 'changeme',
      signOptions: { expiresIn: '7d' },
    }),
  ],
  controllers: [DiaryEventsController],
  providers: [DiaryEventsRepository, DiaryEventsService],
  exports: [DiaryEventsRepository, DiaryEventsService],
})
export class DiaryEventsModule { }
