import { Injectable } from '@nestjs/common';
import { Prisma } from '../generated/prisma';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class DiaryEventsRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findById(id: number) {
    return this.prisma.diaryEvent.findUnique({ where: { id } });
  }

  async findByCreatedById(createdById: string) {
    return this.prisma.diaryEvent.findMany({
      where: { createdById },
      orderBy: { eventDate: 'desc' },
    });
  }

  async findByFilters(filters: { title?: string; createdById?: string }) {
    return this.prisma.diaryEvent.findMany({
      where: {
        title: filters.title,
        createdById: filters.createdById,
      },
      orderBy: { eventDate: 'desc' },
    });
  }

  async create(data: Prisma.DiaryEventCreateInput) {
    return this.prisma.diaryEvent.create({ data });
  }

  async update(id: number, data: Prisma.DiaryEventUpdateInput) {
    return this.prisma.diaryEvent.update({
      where: { id },
      data,
    });
  }

  async delete(id: number) {
    return this.prisma.diaryEvent.delete({ where: { id } });
  }
}
