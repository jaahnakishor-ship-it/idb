import {
  Injectable,
  NotFoundException,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { DiaryEventsRepository } from './diary-events.repository';

@Injectable()
export class DiaryEventsService {
  constructor(private readonly diaryEventsRepository: DiaryEventsRepository) {}

  // CREATE
  async create(data: {
    title: string;
    description?: string;
    eventDate: Date;
    eventTime: string;
    color?: string;
    createdById: string; // NIC of the user
  }) {
    const event = await this.diaryEventsRepository.create({
      title: data.title,
      description: data.description,
      eventDate: data.eventDate,
      eventTime: data.eventTime,
      color: data.color ?? '#3B82F6',
      createdBy: {
        connect: { NIC: data.createdById },
      },
    });

    return event;
  }

  //FIND ALL BY USER 
  async findByUser(createdById: string) {
    const events = await this.diaryEventsRepository.findByCreatedById(createdById);

    if (!events || events.length === 0) {
      throw new NotFoundException(
        `No diary events found for user with NIC ${createdById}`,
      );
    }

    return events;
  }

  // FIND BY FILTERS 
  async findByFilters(filters: { title?: string; createdById?: string }) {
    const events = await this.diaryEventsRepository.findByFilters(filters);

    return events;
  }

  //FIND ONE 
  async findOne(id: number) {
    const event = await this.diaryEventsRepository.findById(id);

    if (!event) {
      throw new NotFoundException(`Diary event with ID ${id} not found`);
    }

    return event;
  }

  // UPDATE 
  async update(
    id: number,
    data: {
      title?: string;
      description?: string;
      eventDate?: Date;
      eventTime?: string;
      color?: string;
      rowVersion: number; // required for conflict check
    },
  ) {
    // Check event exists
    const existing = await this.diaryEventsRepository.findById(id);
    if (!existing) {
      throw new NotFoundException(`Diary event with ID ${id} not found`);
    }

    // rowVersion conflict check
    if (existing.rowVersion !== data.rowVersion) {
      throw new HttpException(
        'Record has been modified by another user. Please refresh and try again.',
        HttpStatus.UNPROCESSABLE_ENTITY,
      );
    }

    const updated = await this.diaryEventsRepository.update(id, {
      ...data,
      rowVersion: existing.rowVersion + 1,
    });

    return updated;
  }

  //DELETE 
  async remove(id: number) {
    // Check event exists first
    const existing = await this.diaryEventsRepository.findById(id);
    if (!existing) {
      throw new NotFoundException(`Diary event with ID ${id} not found`);
    }

    await this.diaryEventsRepository.delete(id);

    return { message: `Diary event with ID ${id} has been deleted successfully` };
  }
}