/** Domain shape for a diary attachment (mirrors `DiaryAttachment` in Prisma). */
export class DiaryAttachmentEntity {
  id!: number;
  fileName!: string;
  fileUrl!: string;
  mimeType!: string;
  fileSizeKb!: number;
  diaryEventId!: number;
  createdById?: string;
  rowVersion!: number;
  uploadedAt!: Date;
}
