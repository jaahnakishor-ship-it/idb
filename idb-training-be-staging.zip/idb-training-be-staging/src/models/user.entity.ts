import { District, UserRole, UserStatus } from '../generated/prisma';

/** Domain shape for a user (mirrors `User` in Prisma; primary key is NIC). */
export class UserEntity {
  NIC!: string;
  name!: string;
  email!: string;
  password!: string;
  role!: UserRole;
  district?: District;
  status!: UserStatus;
  createdById?: string;
  rowVersion!: number;
  createdAt!: Date;
  updatedAt!: Date;
}
