import { District, UserStatus } from '../generated/prisma';

/** Domain shape for a participant (mirrors `Participant` in Prisma). */
export class ParticipantEntity {
  id!: number;
  businessName!: string;
  ownerName!: string;
  email!: string;
  phone!: string;
  district!: District;
  sector!: string;
  registrationNumber!: string;
  status!: UserStatus;
  createdById?: string;
  rowVersion!: number;
  createdAt!: Date;
  updatedAt!: Date;
}
