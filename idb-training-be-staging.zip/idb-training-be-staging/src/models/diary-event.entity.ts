/** Domain shape for a diary event (mirrors `DiaryEvent` in Prisma). */
export class DiaryEventEntity {
  id!: number;
  title!: string;
  description?: string;
  eventDate!: Date;
  eventTime!: string;
  color!: string;
  createdById!: string;
  rowVersion!: number;
  createdAt!: Date;
  updatedAt!: Date;
}
