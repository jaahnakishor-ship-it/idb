import { CompletionStatus } from '../generated/prisma';

/** Domain shape for a program enrollment (mirrors `ProgramEnrollment` in Prisma). */
export class ProgramEnrollmentEntity {
  id!: number;
  programId!: number;
  programName!: string;
  participantId!: number;
  participantName!: string;
  createdById?: string;
  enrollmentDate!: Date;
  completionStatus!: CompletionStatus;
  ticketPrice!: number | null;
  rowVersion!: number;
  createdAt!: Date;
  updatedAt!: Date;
}
