import { District, ProgramStatus, ProgramType } from '../generated/prisma';

/** Domain shape for a training program (mirrors `TrainingProgram` in Prisma). */
export class TrainingProgramEntity {
  id!: number;
  title!: string;
  description?: string;
  sector!: string;
  district!: District;
  startDate!: Date;
  endDate!: Date;
  status!: ProgramStatus;
  programType!: ProgramType;
  totalBudget!: number;
  createdById!: string;
  rowVersion!: number;
  createdAt!: Date;
  updatedAt!: Date;
}
