import type { Prisma } from '../generated/prisma';
import { MatchMode } from '../generated/prisma';

/** Domain shape for a saved analytics query (mirrors `AnalyticsQuery` in Prisma). */
export class AnalyticsQueryEntity {
  id!: number;
  filterRules!: Prisma.JsonValue;
  matchMode!: MatchMode;
  createdById!: string;
  ranAt!: Date;
}
