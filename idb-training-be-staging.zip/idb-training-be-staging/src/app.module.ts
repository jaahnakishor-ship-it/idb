import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

import { PrismaModule } from './prisma/prisma.module';
import { UsersModule } from './users/users.module';
import { TrainingProgramsModule } from './trainingProgram/trainingProgram.module';
import { ParticipantsModule } from './participants/participants.module';
import { ProgramEnrollmentsModule } from './programEnrollments/program-enrollments.module';
import { DiaryEventsModule } from './diaryEvents/diary-events.module';
import { DiaryAttachmentsModule } from './diaryAttachments/diary-attachments.module';
import { AnalyticsQueriesModule } from './analyticsQueries/analytics-queries.module';
import { AuthModule } from './auth/auth.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    PrismaModule,
    UsersModule,
    TrainingProgramsModule,
    ParticipantsModule,
    ProgramEnrollmentsModule,
    DiaryEventsModule,
    DiaryAttachmentsModule,
    AnalyticsQueriesModule,
    AuthModule,
  ]
})
export class AppModule { }
