# IDB Training & Development Analytics Platform

Welcome to the backend documentation for the IDB Training & Development Analytics Platform.

## What is this project?

A web application built for the **Industry Development Board of Sri Lanka** to manage training programs, track SME participant progression, and provide analytics dashboards.

## Documentation

- [Backend Documentation](BACKEND.md) — Framework, architecture, authentication, API conventions, and setup guide.

## Backend Team

Built with NestJS, PostgreSQL, and Prisma ORM.