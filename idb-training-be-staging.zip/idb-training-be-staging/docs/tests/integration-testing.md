# Integration Testing Guide

## 1. Purpose

This guide defines how integration testing should work in this backend and documents the current repository constraints that affect rollout.

For the package overview and dependency rationale, see `docs/tests/packages.md`.

Integration testing is the system-level verification layer for this project:

```text
Client Request
  -> Repository
  -> Prisma
  -> PostgreSQL
  -> Response
```

The goal is to make sure that the repository methods we created are in working order.

**Important:** Integration tests in this backend must not mock repositories, Prisma, or PostgreSQL.

---

## 2. Current Repository Reality

The integration foundation is only partially in place today, so the testing plan needs to match the codebase as it actually exists.

- A basic Nest e2e example already exists at `test/app.e2e-spec.ts`
- A dedicated integration Jest config and setup scaffold now exist under `test/integration`
- `ProgramsModule` and a full `ParticipantsModule` are not yet wired into `AppModule`
- `UsersRepository` now uses the shared `PrismaService` through Nest dependency injection
- `test/integration/setup/test-app.factory.ts` does not yet mirror that middleware and pipe setup, so suites that depend on cookies or DTO validation must apply them explicitly

Because of that, this document should be read as both:

- the target testing standard
- the practical rollout plan from the current state

---

## 3. Testing Scope

Integration testing in this project should be done at three levels.

### 3.1 Repository Integration Tests

Use this when a module already has a repository class.

What this verifies:

- Prisma queries match the schema correctly
- filters return the expected dataset
- create, update, and delete operations persist correctly
- unique constraints and lookup behavior work against the real database

---

## 4. Test Lifecycle

Every integration suite should follow the same lifecycle so tests stay predictable.

### 4.1 `beforeAll`

- load `.env.test` if present
- point Prisma to the test database
- initialize the Nest application
- apply middleware and global pipes needed for parity with runtime behavior
- connect Prisma to the test database

### 4.2 `beforeEach`

- reset the database to a known state
- insert only the records required by the current test

### 4.3 `test`

- execute the repository, service, or HTTP call under test
- assert the response and the database state

### 4.4 `afterAll`

- close the Nest application
- disconnect Prisma

The shared Jest setup in `test/integration/setup/setup.ts` centralizes the database lifecycle so individual suites only need to manage their application instance and test data.

At minimum, suites that cover cookies or DTO validation should apply `cookie-parser` and `ValidationPipe` in the test app before `app.init()`.

---

## 5. Database Reset Strategy

Cleaning the database between tests is mandatory. Tests must never depend on execution order.

### Recommended Option Right Now: Truncate Tables

This repository now uses a simple reset helper in `test/integration/setup/test-db.ts` that truncates the main tables and restarts identities:

```sql
TRUNCATE TABLE
  "DiaryAttachments",
  "DiaryEvents",
  "AnalyticsQueries",
  "ProgramEnrollments",
  "TrainingPrograms",
  "Participants",
  "Users"
RESTART IDENTITY CASCADE;
```

Why this is the current recommendation:

- simple to understand
- reliable with relational data
- good fit while tests run with `--runInBand`

### Option B: Transaction Rollback

Use a per-test transaction and roll it back after each test.

This is faster, but it is more advanced and harder to keep aligned with Nest app instances and Prisma connection handling.

### Option C: Testcontainers

Spin up a fresh PostgreSQL container per run.

This is the strongest long-term option for CI/CD because it gives each pipeline run an isolated database without relying on a developer machine.

---

## 6. Prisma Rule for Application Code

All repository classes in the application must use the shared `PrismaService` via Nest dependency injection.

Required pattern:

```ts
constructor(private readonly prisma: PrismaService) {}
```

Do not do this inside application repositories:

```ts
new PrismaClient();
```

Why this matters:

- tests can guarantee the application uses the test database
- connection lifecycle stays under Nest control
- connection leaks are less likely
- setup and teardown stay consistent across modules

The `UsersRepository` is the immediate example of this rule because it needs to follow the same pattern already used by `ParticipantsRepository`, `ProgramsService`, and `EnrollmentsService`.

Note: test infrastructure is different from application code. A dedicated helper such as `test/integration/setup/test-db.ts` may create or own its own Prisma client because its job is test orchestration, not runtime business logic.

---

## 7. Environment Rules

Never run integration tests against the development database.

Recommended local variables:

```env
NODE_ENV=test
DATABASE_URL=postgresql://postgres:postgres123@localhost:5432/idb_platform_test
DATABASE_URL_TEST=postgresql://postgres:postgres123@localhost:5432/idb_platform_test
JWT_SECRET=test-jwt-secret
```

Current behavior of the integration setup:

- if `.env.test` exists, it is loaded first
- if `DATABASE_URL` is not set but `DATABASE_URL_TEST` is set, the setup maps `DATABASE_URL_TEST` into `DATABASE_URL`
- if no test database URL is available, the test setup throws immediately with a clear error

`.env.test.example` is included as a starting point for local setup.

---

## 8. Error Coverage Strategy

Every module should cover success paths and error paths systematically.

Minimum error matrix:

- invalid input -> `400`
- unauthorized request or invalid credentials -> `401`
- missing record -> `404`
- stale `rowVersion` or duplicate resource -> `409`

This matters because the API contract is not just the happy path. It also includes validation, conflict handling, and authentication behavior.

Examples in this codebase:

- `AuthService.login` should return `401` for invalid credentials
- `ProgramsService.update` should return `409` for stale `rowVersion`
- `EnrollmentsService.create` should return `404` when the program or participant does not exist

---

## 9. Folder Structure

The current integration scaffold is:

```text
docs/
  tests/
    integration-testing.md
    packages.md

test/
  integration/
    auth/
      auth.api.integration-spec.ts
    setup/
      setup.ts
      test-app.factory.ts
      test-db.ts
  jest-integration.json
```

As coverage expands, the target structure should grow into:

```text
test/
  integration/
    auth/
      auth.api.integration-spec.ts
    users/
      users.repository.integration-spec.ts
      users.service.integration-spec.ts
      users.api.integration-spec.ts
    programs/
      programs.service.integration-spec.ts
      programs.api.integration-spec.ts
    participants/
      participants.repository.integration-spec.ts
      participants.service.integration-spec.ts
      participants.api.integration-spec.ts
```

---

## 10. Jest Configuration

The integration runner should stay separate from the default unit and e2e commands.

`test/jest-integration.json`

```json
{
  "moduleFileExtensions": ["js", "json", "ts"],
  "rootDir": ".",
  "testEnvironment": "node",
  "testRegex": ".integration-spec.ts$",
  "transform": {
    "^.+\\.(t|j)s$": "ts-jest"
  },
  "setupFilesAfterEnv": ["<rootDir>/test/integration/setup/setup.ts"]
}
```

Recommended scripts:

```json
{
  "scripts": {
    "test:integration": "jest --config ./test/jest-integration.json --runInBand",
    "test:integration:watch": "jest --config ./test/jest-integration.json --watch"
  }
}
```

Use `--runInBand` until database isolation is fully stable.

---

## 11. Canonical Auth Example

The first concrete integration example in this repository should be the auth API suite.

Reference file:

- `test/integration/auth/auth.api.integration-spec.ts`

That suite demonstrates:

- register a user through the real API
- verify the password is persisted hashed
- log in through the real API
- assert that the `access_token` cookie is returned
- reject invalid credentials with `401`

Minimal example shape:

```ts
describe('Auth API (integration)', () => {
  let app: INestApplication;

  beforeAll(async () => {
    app = await createTestApp();
  });

  afterAll(async () => {
    await app.close();
  });

  it('logs in and sets the access_token cookie', async () => {
    // arrange test data
    // call /auth/login
    // assert status, cookie, and response body
  });
});
```

This removes ambiguity for new contributors and gives future suites a consistent reference point.

---

## 12. What to Cover First

### Users

- create user successfully
- verify password hashing through the service path
- fetch, update, and delete by NIC

### Programs

- create and fetch programs
- filter programs
- update successfully with the correct `rowVersion`
- reject stale `rowVersion` with `409`

### Participants

- expand coverage after the full Nest module, controller, and service stack is added

---

## 14. Definition of Done

The integration foundation is in a good state when the project has:

1. a dedicated integration Jest config
2. shared setup helpers for app and database lifecycle
3. a dedicated test database that is reset safely
4. repository classes using the shared `PrismaService`
5. a stable auth integration suite as the reference example
6. systematic success and error coverage for each major module
