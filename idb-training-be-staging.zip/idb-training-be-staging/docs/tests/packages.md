# Packages for Backend Integration Testing

## 1. Purpose

This document lists the packages used for backend integration testing and explains why they matter in this repository.

For testing strategy, lifecycle, and implementation details, see `docs/tests/integration-testing.md`.

The target integration stack is:

```text
Jest
  -> Repository
  -> Prisma
  -> PostgreSQL
```

**Important:** These packages are used to exercise real backend behavior. Integration tests in this project must not mock services, repositories, Prisma, or the database.

---

## 2. Core Packages Already Available

The following packages are already present in this repository and are part of the integration-testing path.

| Package             | Purpose                                                       | Status    |
| ------------------- | ------------------------------------------------------------- | --------- |
| `jest`              | Main test runner and assertion framework                      | Installed |
| `ts-jest`           | Executes TypeScript test files in Jest                        | Installed |
| `@types/jest`       | Type support for Jest APIs                                    | Installed |
| `@nestjs/testing`   | Creates real Nest testing modules and app instances           | Installed |
| `supertest`         | Sends real HTTP requests to the Nest app                      | Installed |
| `@types/supertest`  | Type support for Supertest                                    | Installed |
| `prisma`            | Runs Prisma CLI commands and migrations                       | Installed |
| `@prisma/client`    | Real ORM client used by the app and tests                     | Installed |
| `pg`                | PostgreSQL driver used by Prisma                              | Installed |
| `cookie-parser`     | Required when authenticated routes read cookies from requests | Installed |
| `class-validator`   | Powers DTO validation used in API-level tests                 | Installed |
| `class-transformer` | Supports DTO transformation for validated request payloads    | Installed |

---

## 3. What Each Package Does

### `jest`

Runs the test suite and provides assertions plus lifecycle hooks such as `beforeAll`, `beforeEach`, and `afterAll`.

### `ts-jest`

Allows Jest to execute `.ts` files without precompiling the entire test suite.

### `@nestjs/testing`

Creates a real Nest testing module and application instance so tests can use actual controllers, services, repositories, and providers together.

### `prisma`

Supports schema management, migrations, and other CLI operations needed to prepare the test database.

### `@prisma/client`

Provides real database access from the application and from test infrastructure helpers.

In test runs, Prisma must always point to the test database.

### `pg`

Provides the PostgreSQL transport layer under Prisma.

---


## 4. Environment and Setup Helpers

Integration tests also depend on environment handling.

### `dotenv`

The repository already uses `dotenv` through existing tooling and imports. It is useful for loading `.env.test` so the integration suite always targets the test database.

Typical responsibilities:

- load `.env.test`
- set `NODE_ENV=test`
- map `DATABASE_URL_TEST` into `DATABASE_URL` when needed
- ensure `JWT_SECRET` exists for auth flows

Note: Database setup, migrations, and cleanup strategy are covered in the integration testing guide.

---

## 5. Recommended Additional Packages

These are not required for the initial auth integration scaffold, but they are valuable as the suite grows.

| Package          | Why It Helps                                                                    | Priority              |
| ---------------- | ------------------------------------------------------------------------------- | --------------------- |
| `cross-env`      | Sets environment variables consistently across operating systems in npm scripts | Recommended           |
| `testcontainers` | Creates an isolated PostgreSQL instance for local and CI integration runs       | Recommended for CI/CD |

---

## 6. Why These Packages Work Together

- `jest` runs the suite
- `ts-jest` executes TypeScript specs
- `@nestjs/testing` builds the real Nest app
- `@prisma/client` and `pg` connect to the real PostgreSQL database
- `dotenv` helps keep test environment configuration separate from development

---

## 7. Example Command Set

The integration suite should be run through dedicated scripts:

```bash
npm run test:integration
npm run test:integration:watch
```

Until the database lifecycle is fully hardened, the default integration run should stay serial with `--runInBand`.

---

## 8. Summary

For this backend, the most important integration-testing packages are:

- `jest`
- `ts-jest`
- `@nestjs/testing`
- `prisma`
- `@prisma/client`
- `pg`
