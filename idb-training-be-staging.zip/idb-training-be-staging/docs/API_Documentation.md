# IDB Training and Development Analytics Paltform - API Documentation


**Version:** 1.0
**Last Update:** April 2026
**Team:** Backend (Problem 1)
**Base URL:** 'http://localhost:3000/api'

--

## 1. Introduction

This document describes all the REST API endpoints exposed by the IDB Training and Development Analytics Paltform backend.

The API is consumed by the React.JS frontend and is responsible for:

- User and Participant management
- Trianing Program Management
- Program enrollement Tracking
- Digital Diary and Field notes
- Analytics and Reporting

All request and response bodies use **JSON format** unless stated otherwise.

All endpoint require the user to be **authenticated** via an HTTP-only cookie set at login. Unauthorized login will recieve a  '401 Unauthorized' response.

--

## 2. Base URL


|  Environment  |            URL               |

|  Development  | 'http://localhost:3000/api'  |
|  Production   |  TBD                         |


All endpoint paths in this document are relative to the base URL.
for example,  'GET/Users'  means 'GET http://localhost:3000/api/users'

--


## 3. Authentication

This API uses **JWT tockens stored in HTTP-only cookies** for authentification. The frontend does not need to manually attach any token requests - The browser handles the cookie automatically.

---

### POST/auth/login

Authenticates a user and sets an HTTP-only cookie containing the JWT token.

**Authentication required:** No

**Request Body:**

|      Feild        |       Type        |       Required        |       Description     |
|-------------------|-------------------|-----------------------|-----------------------|
|       email       |       String      |       Yes             |     User's Email      |
|     Password      |       String      |       Yes             |  User's Password      |

**Example Request:**

```json
{
    "email": "zainab@idb.gov.lk",
    "Password": "Securepassword123"
}
```

**Example Success Response - '200 OK' :**

```json
{
    "Message": "Login Successful",
    "User": {
        "NIC": "200057803262",
        "name": "Zainab Rikaz",
        "email": "zainab@idb.gov.lk",
        "role": "system_admin",
        "district": null,
        "status": "active"
    }
}
```

**Note:** The JWT Token is NOT returned in the response body.It is set automatically as an HTTP-only Cookie named `access token`.

**Possible Errors:**

|       Status      |         Message       |               Reason          |
|-------------------|-----------------------|-------------------------------|
|       400         |   Validation Failed   |   Missing email or password   |
|       401         |   Invalid Credentials |   Wrong email or Password     |


---


### POST/auth/Logout

clears the authentification cookie and ends the session.

**Authentication Required:** Yes

**Request Body:** None

**Example Success Response - `200 OK`:**
```json
{
    "message": "Logged out successfully"
}
```

---

### GET /auth/me 

Return the currently authenticated user's profile based on the cookie.

**Authentication required:** Yes

**Request Body:** None

**Example Success REsponse - `200 OK` :**
```json

{
    "NIC": "2000185231",
    "name": "Zainab Rikaz",
    "email": "zainab@idb.gov.lk",
    "role": "system_admin",
    "district": null,
    "status": "active",
    "createdAt": "2026-01-15T08:30:00.000Z",
    "updatedAt": "2026-03-01T10:00:00.000Z"
}
```

**Possible Errors:**

|       Status      |       Message     |       Reason                      |
|-------------------|-------------------|-----------------------------------|
|      401          |    Unauthorized   |     No Cookie or Token Expired    |


---

## 4. Error Format

All response from the API follow a consistent JSON structure.

**Example Error Response:**
```json

{
    "statusCode": 404,
    "message": "User not found",
    "error" : "Not Found"

}
```

---

### Standard HTTP Status Codes used in this API

| Status Code | Meaning               | When It Occurs                                      |
|-------------|-----------------------|-----------------------------------------------------|
|    200      |       OK              |    Request succeeded                                |
|    201      |     Created           |   New Record Successfuly created                    |
|    400      |    Bad REquest        |  Missing or invalid feilds in the request body      |
|    401      |    Unauthorized       |  No cookie present or JWT token expired             |
|    403      |    Forbidden          |  Authenticated but not allowed to perform the action|
|    404      |   Not Found           |  Requested REcord doesnot exist                     |
|    409      |   Conflict            |   Duplicate Entry (e.g. email or NIC already exist) |
|    422      |  Unprocessable Entry  |  Row version Mismatch - optimmistic concurrency     |
|    500      | Internal Server Error |   Unexpected Server Side Error                      |      


## 5. Pagination, Search and Filter

All `GET` list endpoints support pagination, search, and filtering via query parameters.

**Example:**

GET/api/users?page=1&limit=10&search=zainab&role-System_administrator&status=active

###Query Parameters

| Parameter | Type   | Default | Description                        |
|-----------|--------|---------|------------------------------------|
| page      | number | 1       | Page number                        |
| limit     | number | 10      | Number of records per page         |
| search    | string | —       | Search by name or email            |
| status    | string | —       | Filter by status (active/inactive) |



### Standard Pagination Response Structure

All list endpoints return data in this format:
```json
{
    "data": [],
    "meta": {
        "total": 100,
        "Page": 1,
        "limit": 10,
        "totalPages": 10
    }
}
```

| Field           | Description                              |
|-----------------|------------------------------------------|
| data            | Array of records for the current page    |
| meta.total      | Total number of records in the database  |
| meta.page       | Current page number                      |
| meta.limit      | Records per page                         |
| meta.totalPages | Total number of pages               |

---

## 6. RowVersion - Optimistic Concurrency Control

Every table in the database include a `rowVersion` feild.This  prevents two users from overwriting each other's changes at the same time.


### How it works 

1. Frontend fetches a record - response include `"rowVersion":1`
2. Frontend send a `PUT` request to update -- must include `"rowVersion":1` in the request body.
3. Backend checks if the rowVersion in the request matches the one in the database.
4. If they **match** - Update Proceeds, `"rowVersion"` increments to 2
5. If they **do not match** - request is rejected with `422`


### Rule 

> Every `PUT` request body must include the current `rowVersion`
> of the record being updated. if it is missing or incorrect, 
> the update will be rejected.

### Example Conflict Error - `422 Unprocessable Entity`

```json
{
    "statusCode": 422,
    "message": "Record has been modified by another user.
                Please refresh and try again.",
    "error": "Unprocessable Entity"
} 
```

# Users Module — API Documentation

**Base URL:** `http://localhost:3000/api`  
**Module Path:** `/users`  
**Last Updated:** April 2026

---

## Overview

The Users module handles all user account management for the IDB Training & Development Analytics Platform. All endpoints in this module require the user to be authenticated via an HTTP-only cookie set at login.

---

## User Object

This is the standard User object returned by most endpoints in this module.

| Field       | Type      | Description                                      |
|-------------|-----------|--------------------------------------------------|
| id          | integer   | Auto-incremented unique identifier               |
| name        | string    | Full name of the user (max 100 characters)       |
| email       | string    | Unique email address (max 150 characters)        |
| role        | UserRole  | Role assigned to the user (see Roles below)      |
| district    | District  | Assigned district — nullable for some roles      |
| status      | UserStatus| Account status: `active` or `inactive`           |
| rowVersion  | integer   | Used for optimistic concurrency control          |
| createdAt   | datetime  | Timestamp when the account was created (ISO 8601)|
| updatedAt   | datetime  | Timestamp of the last update (ISO 8601)          |

> **Note:** `password` is never returned in any response.

---

## Enums

### UserRole

| Value          | Description                        |
|----------------|------------------------------------|
| system_admin   | Full system access                 |
| epo_do         | EPO / District Officer             |
| ma_clerk       | Management Assistant / Clerk       |
| ad_dd          | Assistant Director / Deputy Director|
| hod_manager    | Head of Department / Manager       |
| board_chairman | Board Chairman                     |

### UserStatus

| Value    | Description          |
|----------|----------------------|
| active   | Account is active    |
| inactive | Account is disabled  |

### District

Valid district values: `Colombo`, `Gampaha`, `Kurunegala`, `Kandy`, `Matale`, `Nuwara_Eliya`, `Galle`, `Matara`, `Hambantota`, `Ampara`, `Trincomalee`, `Batticaloa`, `Mullaitivu`, `Puttalam`, `Anuradhapura`, `Polonnaruwa`, `Badulla`, `Monaragala`, `Ratnapura`, `Kegalle`, `Jaffna`, `Kilinochchi`, `Mannar`, `Vavuniya`

---

## Endpoints

### GET /users

Returns a paginated list of all users in the system.

**Authentication required:** Yes

**Query Parameters:**

| Parameter | Type    | Required | Default | Description                              |
|-----------|---------|----------|---------|------------------------------------------|
| page      | integer | No       | 1       | Page number                              |
| limit     | integer | No       | 10      | Number of results per page               |
| search    | string  | No       | —       | Filter by name or email (partial match)  |
| role      | string  | No       | —       | Filter by UserRole                       |
| status    | string  | No       | —       | Filter by UserStatus (`active`/`inactive`)|
| district  | string  | No       | —       | Filter by District                       |

**Example Request:**

```
GET /api/users?page=1&limit=10&role=epo_do&status=active
```

**Example Success Response — `200 OK`:**

```json
{
  "data": [
    {
      "id": 1,
      "name": "Amara Perera",
      "email": "amara.perera@idb.gov.lk",
      "role": "epo_do",
      "district": "Colombo",
      "status": "active",
      "rowVersion": 1,
      "createdAt": "2026-01-15T08:30:00.000Z",
      "updatedAt": "2026-03-01T10:00:00.000Z"
    },
    {
      "id": 2,
      "name": "Nimal Silva",
      "email": "nimal.silva@idb.gov.lk",
      "role": "epo_do",
      "district": "Gampaha",
      "status": "active",
      "rowVersion": 2,
      "createdAt": "2026-01-20T09:00:00.000Z",
      "updatedAt": "2026-02-10T11:30:00.000Z"
    }
  ],
  "meta": {
    "total": 45,
    "page": 1,
    "limit": 10,
    "totalPages": 5
  }
}
```

**Possible Errors:**

| Status | Message        | Reason                              |
|--------|----------------|-------------------------------------|
| 401    | Unauthorized   | Not authenticated / cookie expired  |

---

### GET /users/:id

Returns a single user by their ID.

**Authentication required:** Yes

**Path Parameters:**

| Parameter | Type    | Required | Description       |
|-----------|---------|----------|-------------------|
| id        | integer | Yes      | The user's ID     |

**Example Request:**

```
GET /api/users/1
```

**Example Success Response — `200 OK`:**

```json
{
  "id": 1,
  "name": "Amara Perera",
  "email": "amara.perera@idb.gov.lk",
  "role": "epo_do",
  "district": "Colombo",
  "status": "active",
  "rowVersion": 1,
  "createdAt": "2026-01-15T08:30:00.000Z",
  "updatedAt": "2026-03-01T10:00:00.000Z"
}
```

**Possible Errors:**

| Status | Message        | Reason                              |
|--------|----------------|-------------------------------------|
| 401    | Unauthorized   | Not authenticated / cookie expired  |
| 404    | User not found | No user exists with the given ID    |

---

### POST /users

Creates a new user account.

**Authentication required:** Yes

**Request Body:**

| Field    | Type      | Required | Description                                        |
|----------|-----------|----------|----------------------------------------------------|
| name     | string    | Yes      | Full name (max 100 characters)                     |
| email    | string    | Yes      | Unique email address (max 150 characters)          |
| password | string    | Yes      | Account password (min 8 characters recommended)   |
| role     | UserRole  | No       | Defaults to `epo_do` if not provided              |
| district | District  | No       | Required for district-based roles                 |
| status   | UserStatus| No       | Defaults to `active` if not provided              |

**Example Request:**

```json
{
  "name": "Kasun Fernando",
  "email": "kasun.fernando@idb.gov.lk",
  "password": "SecurePass@123",
  "role": "ma_clerk",
  "district": "Kandy",
  "status": "active"
}
```

**Example Success Response — `201 Created`:**

```json
{
  "id": 46,
  "name": "Kasun Fernando",
  "email": "kasun.fernando@idb.gov.lk",
  "role": "ma_clerk",
  "district": "Kandy",
  "status": "active",
  "rowVersion": 1,
  "createdAt": "2026-04-05T07:45:00.000Z",
  "updatedAt": "2026-04-05T07:45:00.000Z"
}
```

**Possible Errors:**

| Status | Message                  | Reason                                      |
|--------|--------------------------|---------------------------------------------|
| 400    | Validation failed        | Missing required fields or invalid values   |
| 401    | Unauthorized             | Not authenticated / cookie expired          |
| 409    | Email already exists     | Another user is already using this email    |

---

### PUT /users/:id

Updates an existing user's details. Requires `rowVersion` for optimistic concurrency control.

**Authentication required:** Yes

**Path Parameters:**

| Parameter | Type    | Required | Description   |
|-----------|---------|----------|---------------|
| id        | integer | Yes      | The user's ID |

**Request Body:**

| Field      | Type      | Required | Description                                              |
|------------|-----------|----------|----------------------------------------------------------|
| rowVersion | integer   | Yes      | Must match the current rowVersion in the database        |
| name       | string    | No       | Updated full name                                        |
| email      | string    | No       | Updated email address                                    |
| password   | string    | No       | Updated password                                         |
| role       | UserRole  | No       | Updated role                                             |
| district   | District  | No       | Updated district                                         |
| status     | UserStatus| No       | Updated status                                           |

> **Important:** `rowVersion` is mandatory. If the value sent does not match what is currently stored in the database, the update will be rejected with a `409 Conflict` error. This prevents two users from overwriting each other's changes. Always use the `rowVersion` from the most recent GET response.

**Example Request:**

```json
{
  "rowVersion": 1,
  "district": "Galle",
  "status": "inactive"
}
```

**Example Success Response — `200 OK`:**

```json
{
  "id": 46,
  "name": "Kasun Fernando",
  "email": "kasun.fernando@idb.gov.lk",
  "role": "ma_clerk",
  "district": "Galle",
  "status": "inactive",
  "rowVersion": 2,
  "createdAt": "2026-04-05T07:45:00.000Z",
  "updatedAt": "2026-04-05T09:10:00.000Z"
}
```

> **Note:** `rowVersion` increments by 1 after every successful update. Use the new value in any subsequent PUT request.

**Possible Errors:**

| Status | Message                  | Reason                                          |
|--------|--------------------------|-------------------------------------------------|
| 400    | Validation failed        | Invalid field values                            |
| 401    | Unauthorized             | Not authenticated / cookie expired              |
| 404    | User not found           | No user exists with the given ID                |
| 409    | Conflict                 | rowVersion mismatch — record was updated by someone else |

---

### DELETE /users/:id

Permanently deletes a user account.

**Authentication required:** Yes

**Path Parameters:**

| Parameter | Type    | Required | Description   |
|-----------|---------|----------|---------------|
| id        | integer | Yes      | The user's ID |

**Example Request:**

```
DELETE /api/users/46
```

**Example Success Response — `200 OK`:**

```json
{
  "message": "User deleted successfully"
}
```

**Possible Errors:**

| Status | Message        | Reason                              |
|--------|----------------|-------------------------------------|
| 401    | Unauthorized   | Not authenticated / cookie expired  |
| 404    | User not found | No user exists with the given ID    |

---

## Summary Table

| Method | Endpoint       | Description          | Auth Required |
|--------|----------------|----------------------|---------------|
| GET    | /api/users     | List all users       | Yes           |
| GET    | /api/users/:id | Get a single user    | Yes           |
| POST   | /api/users     | Create a new user    | Yes           |
| PUT    | /api/users/:id | Update a user        | Yes           |
| DELETE | /api/users/:id | Delete a user        | Yes           |
# Backend Framework Documentation

**Task:** T001 | **Location:** /docs/BACKEND.md | **Version:** 1.0 | **Team:** Backend

---

## 1. Overview

This document describes the planned backend framework, architecture decisions, folder structure, packages, and development guidelines for the IDB Training & Development Analytics Platform.

The backend is responsible for:

- Exposing RESTful API endpoints consumed by the React.js frontend
- Handling authentication and role-based access control (RBAC)
- Managing all business logic — programs, participants, financials, analytics
- Communicating with the PostgreSQL database via Prisma ORM

---

## 2. Technology Stack

| Layer | Technology | Version | Reason |
|---|---|---|---|
| Runtime | Node.js | v22+ | JavaScript runtime, fast, widely used |
| Framework | NestJS | v10+ | Structured, scalable, built-in modules, services, repositories |
| Language | TypeScript | v5+ | Type safety, catches errors at compile time |
| Database | PostgreSQL | v16 | Relational database, best for structured data and analytics |
| ORM | Prisma | v7+ | Type-safe database client, clean migrations, auto-generated client |
| Authentication | JWT + HTTP-only Cookies | --- | Secure token-based auth, cookie prevents XSS attacks |
| Password Hashing | bcryptjs | v2.4+ | Industry standard for hashing passwords before storing |
| Validation | class-validator | --- | Validates incoming request data automatically |
| Containerization | Docker | --- | Consistent environment across all machines |

---

## 3. Why NestJS Over Express

| Feature | Express.js | NestJS |
|---|---|---|
| Structure | Manual — you build it yourself | Built-in modules, controllers, services |
| TypeScript | Optional | Default |
| Repository pattern | Manual setup required | Built-in support |
| Validation | Manual | Built-in with class-validator |
| Fits task T006 | Partially | Perfectly |

NestJS was chosen because T006 explicitly requires models, repositories, services, and APIs as separate layers — NestJS enforces this structure by design.

---

## 4. Layered Architecture

Every feature in the backend follows this strict layered pattern:
```
HTTP Request
    ↓
Controller  →  Handles HTTP request and response
    ↓
Service     →  Contains all business logic
    ↓
Repository  →  Communicates with the database
    ↓
Entity      →  Defines the database table structure
    ↓
PostgreSQL DB  →  Stores the data
```

| Layer | File | Responsibility |
|---|---|---|
| Controller | *.controller.ts | Receives request, calls service, returns response |
| Service | *.service.ts | Business logic, validation rules, calculations |
| Repository | *.repository.ts | Database queries — find, save, update, delete |
| Entity | *.entity.ts | Defines table columns, relationships, constraints |
| Module | *.module.ts | Wires everything together |
| DTO | *.dto.ts | Defines the shape of incoming request data |

---

## 5. Row Version — Optimistic Concurrency Control

Every table in the database must include a row version column. This is mandatory as stated in T006.

### What it is

Row Version is a number that increments by 1 every time a record is updated. Before updating a record, the system checks if the `rowVersion` in the request matches the `rowVersion` in the database. If they do not match, it means someone else has already updated the record and the request is rejected.

### Why it is needed

Prevents two users from overwriting each other's changes at the same time.

### Example
```
User A reads record → rowVersion = 1
User B reads record → rowVersion = 1
User A updates → rowVersion becomes 2 ✅
User B tries to update with rowVersion 1 → REJECTED ❌
```

### Implementation in every entity
```typescript
@VersionColumn()
rowVersion: number;
```

---

## 6. Authentication Flow — HTTP-only Cookies

Authentication uses JWT tokens stored in HTTP-only cookies — not in localStorage or Authorization headers.

1. User sends `POST /api/auth/login` with email and password
2. Backend finds user by email in the database
3. Backend compares entered password with bcrypt hash
4. If match — generate JWT token
5. Return token inside `Set-Cookie` header with `HttpOnly`, `Secure`, `SameSite` flags
6. Browser stores cookie automatically
7. Every subsequent request sends the cookie automatically
8. Auth middleware reads token from cookie and validates it
9. If valid — attach user to request and allow access
10. `POST /api/auth/logout` clears the cookie

| Cookie Flag | Purpose |
|---|---|
| HttpOnly | JavaScript cannot read the cookie — prevents XSS attacks |
| Secure | Cookie only sent over HTTPS |
| SameSite=Strict | Cookie not sent with cross-site requests — prevents CSRF attacks |

---

## 7. API Conventions

### Base URL
```
http://localhost:3000/api
```

### Endpoint Naming
```
GET    /api/users          Get all users (paginated)
GET    /api/users/:id      Get one user
POST   /api/users          Create user
PUT    /api/users/:id      Update user
DELETE /api/users/:id      Delete user

POST   /api/auth/login     Login
POST   /api/auth/logout    Logout
GET    /api/auth/me        Get current user
```

### Pagination, Search and Filter

All GET list endpoints must support pagination, search, and filter as required by T006.
```
GET /api/users?page=1&limit=10&search=zainab&role=admin&status=active
```

| Parameter | Type | Description |
|---|---|---|
| page | number | Page number — default 1 |
| limit | number | Items per page — default 10 |
| search | string | Search by name or email |
| role | string | Filter by role |
| status | string | Filter by status |

---

## 8. Environment Variables

Copy `.env.example` to `.env` and fill in your values. Never commit `.env` to Git.
```env
PORT=3000
NODE_ENV=development
DB_HOST=localhost
DB_PORT=5432
DB_NAME=idb_platform
DB_USER=postgres
DB_PASSWORD=your_password_here
JWT_SECRET=your_super_secret_key_change_this
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

---

## 9. How to Set Up and Run

### Prerequisites

- Node.js v22+
- PostgreSQL v16
- Docker Desktop
- Git

### Steps

1. Clone the repository and go into the backend folder
2. Run: `npm install`
3. Copy `.env.example` to `.env` and fill in your PostgreSQL password and JWT secret
4. Run in development mode: `npm run start:dev`
5. Open browser at `http://localhost:3000` to verify it is running

### Running with Docker
```bash
docker-compose up --build   # start all containers
docker-compose down         # stop all containers
```

---

## 10. Git Workflow

### Branch Structure
```
main                         → production code only
develop                      → main development branch
feature/T006-users-module
feature/T007-auth
```

### Branch Naming
```
feature/<task-id>-<short-description>
fix/<task-id>-<short-description>
```

### Commit Message Convention
```
feat: add user entity with row version
fix: correct password hashing in user service
docs: update backend documentation
test: add unit tests for user service
```

---

*Backend Team — IDB Platform — Version 1.0 — March 2026*# Diary Attachments API

**Base URL:** `http://localhost:3000/api`  
**Authentication:** All endpoints require a valid JWT cookie (HTTP-only). Requests without a valid session will receive `401 Unauthorized`.

---

## Model Reference

| Field         | Type       | Constraints                           | Description                                          |
|---------------|------------|---------------------------------------|------------------------------------------------------|
| `id`          | `Int`      | Primary Key, Auto-increment           | Unique identifier for the attachment                 |
| `fileName`    | `String`   | `VarChar(255)`, Required              | Original name of the uploaded file                   |
| `fileUrl`     | `String`   | `VarChar(500)`, Required              | Server path or URL where the file is stored          |
| `mimeType`    | `String`   | `VarChar(100)`, Required              | MIME type of the file (e.g. `application/pdf`)       |
| `fileSizeKb`  | `Int`      | Required                              | Size of the file in kilobytes                        |
| `diaryEventId`| `Int`      | FK → `DiaryEvent.id`, Required        | ID of the parent diary event                         |
| `uploadedAt`  | `DateTime` | Auto-set on creation                  | Timestamp when the attachment was uploaded           |

> **Note:** `DiaryAttachment` does not have a `rowVersion` field. Attachments are not updated in place — they are uploaded (created) and deleted only.

---

## Endpoints

### 1. Get All Attachments for a Diary Event

Retrieves all attachments belonging to a specific diary event.

```
GET /api/diary-events/:eventId/attachments
```

**Path Parameters**

| Parameter  | Type     | Required | Description                      |
|------------|----------|----------|----------------------------------|
| `eventId`  | `number` | Yes      | ID of the parent diary event     |

**Example Request**

```
GET /api/diary-events/1/attachments
```

**Success Response — `200 OK`**

```json
[
  {
    "id": 1,
    "fileName": "agenda.pdf",
    "fileUrl": "/uploads/diary/1/agenda.pdf",
    "mimeType": "application/pdf",
    "fileSizeKb": 204,
    "diaryEventId": 1,
    "uploadedAt": "2026-04-15T08:05:00.000Z"
  },
  {
    "id": 2,
    "fileName": "participants-list.xlsx",
    "fileUrl": "/uploads/diary/1/participants-list.xlsx",
    "mimeType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "fileSizeKb": 87,
    "diaryEventId": 1,
    "uploadedAt": "2026-04-15T08:10:00.000Z"
  }
]
```

**Error Responses**

| Status | Code              | Description                                   |
|--------|-------------------|-----------------------------------------------|
| `404`  | `EVENT_NOT_FOUND` | No diary event found with the given `eventId` |

---

### 2. Get Single Attachment by ID

Retrieves metadata for a single attachment. Does not return the file binary — use `fileUrl` to access the file directly.

```
GET /api/diary-events/:eventId/attachments/:id
```

**Path Parameters**

| Parameter  | Type     | Required | Description                      |
|------------|----------|----------|----------------------------------|
| `eventId`  | `number` | Yes      | ID of the parent diary event     |
| `id`       | `number` | Yes      | ID of the attachment             |

**Success Response — `200 OK`**

```json
{
  "id": 1,
  "fileName": "agenda.pdf",
  "fileUrl": "/uploads/diary/1/agenda.pdf",
  "mimeType": "application/pdf",
  "fileSizeKb": 204,
  "diaryEventId": 1,
  "uploadedAt": "2026-04-15T08:05:00.000Z"
}
```

**Error Responses**

| Status | Code                   | Description                                          |
|--------|------------------------|------------------------------------------------------|
| `404`  | `EVENT_NOT_FOUND`      | No diary event found with the given `eventId`        |
| `404`  | `ATTACHMENT_NOT_FOUND` | No attachment found with that ID under this event    |

---

### 3. Upload Attachment to a Diary Event

Uploads a file and attaches it to an existing diary event. The request must be sent as `multipart/form-data`.

```
POST /api/diary-events/:eventId/attachments
```

**Path Parameters**

| Parameter  | Type     | Required | Description                      |
|------------|----------|----------|----------------------------------|
| `eventId`  | `number` | Yes      | ID of the parent diary event     |

**Request Format**

`Content-Type: multipart/form-data`

| Field    | Type   | Required | Description                     |
|----------|--------|----------|---------------------------------|
| `file`   | `File` | Yes      | The file to upload              |

**Example Request (curl)**

```bash
curl -X POST http://localhost:3000/api/diary-events/1/attachments \
  -H "Cookie: access_token=<your_jwt>" \
  -F "file=@agenda.pdf"
```

**Accepted File Types**

| MIME Type                                                                 | Extension |
|---------------------------------------------------------------------------|-----------|
| `application/pdf`                                                         | `.pdf`    |
| `image/jpeg`                                                              | `.jpg`, `.jpeg` |
| `image/png`                                                               | `.png`    |
| `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`      | `.xlsx`   |
| `application/vnd.openxmlformats-officedocument.wordprocessingml.document`| `.docx`   |

**File Size Limit:** 5 MB per file.

**Success Response — `201 Created`**

```json
{
  "id": 3,
  "fileName": "agenda.pdf",
  "fileUrl": "/uploads/diary/1/agenda.pdf",
  "mimeType": "application/pdf",
  "fileSizeKb": 204,
  "diaryEventId": 1,
  "uploadedAt": "2026-04-15T12:00:00.000Z"
}
```

**Error Responses**

| Status | Code                    | Description                                          |
|--------|-------------------------|------------------------------------------------------|
| `404`  | `EVENT_NOT_FOUND`       | No diary event found with the given `eventId`        |
| `400`  | `NO_FILE_PROVIDED`      | Request did not include a file                       |
| `400`  | `INVALID_FILE_TYPE`     | File MIME type is not in the accepted list           |
| `400`  | `FILE_TOO_LARGE`        | File exceeds the 5 MB size limit                     |

---

### 4. Delete Attachment

Deletes a specific attachment record and removes the associated file from storage.

```
DELETE /api/diary-events/:eventId/attachments/:id
```

**Path Parameters**

| Parameter  | Type     | Required | Description                      |
|------------|----------|----------|----------------------------------|
| `eventId`  | `number` | Yes      | ID of the parent diary event     |
| `id`       | `number` | Yes      | ID of the attachment to delete   |

**Success Response — `200 OK`**

```json
{
  "message": "Attachment deleted successfully."
}
```

**Error Responses**

| Status | Code                   | Description                                          |
|--------|------------------------|------------------------------------------------------|
| `404`  | `EVENT_NOT_FOUND`      | No diary event found with the given `eventId`        |
| `404`  | `ATTACHMENT_NOT_FOUND` | No attachment found with that ID under this event    |

---

## Notes

- All attachment endpoints are **nested under** `/api/diary-events/:eventId/` to make the parent–child relationship explicit.
- `fileName` stores the **original** name of the file as uploaded by the user. The file may be stored under a different name on disk to avoid collisions.
- `fileUrl` is a server-relative path. The frontend should prepend the base URL (`http://localhost:3000`) to construct the full download link.
- `fileSizeKb` is calculated server-side from the uploaded file — it is **not** accepted in the request body.
- `mimeType` is determined server-side from the actual file content, not the file extension.
- There is **no update endpoint** for attachments. To replace a file, delete the existing attachment and upload a new one.
- When a parent `DiaryEvent` is deleted, all its attachments are automatically deleted via cascade — both the database records and the stored files should be cleaned up.
# Diary Events API

**Base URL:** `http://localhost:3000/api`  
**Authentication:** All endpoints require a valid JWT cookie (HTTP-only). Requests without a valid session will receive `401 Unauthorized`.

---

## Model Reference

| Field         | Type       | Constraints                              | Description                                      |
|---------------|------------|------------------------------------------|--------------------------------------------------|
| `id`          | `Int`      | Primary Key, Auto-increment              | Unique identifier for the diary event            |
| `title`       | `String`   | `VarChar(200)`, Required                 | Title of the diary event                         |
| `description` | `String`   | `VarChar(1000)`, Optional                | Detailed description of the event                |
| `eventDate`   | `DateTime` | Required                                 | Date of the event (ISO 8601)                     |
| `eventTime`   | `String`   | `VarChar(10)`, Required                  | Time of the event (e.g. `"09:30"`)               |
| `color`       | `String`   | `VarChar(7)`, Default `"#3B82F6"`        | Hex colour used in the calendar UI               |
| `createdById` | `String`   | `VarChar(12)`, FK → `User.NIC`           | NIC of the user who created the event            |
| `rowVersion`  | `Int`       | Default `1`, Required on updates         | Optimistic concurrency control version number    |
| `createdAt`   | `DateTime` | Auto-set on creation                     | Timestamp when the record was created            |
| `updatedAt`   | `DateTime` | Auto-updated                             | Timestamp when the record was last updated       |

---

## Endpoints

### 1. Get All Diary Events

Retrieves a paginated list of diary events. Supports filtering by date range and search by title.

```
GET /api/diary-events
```

**Query Parameters**

| Parameter   | Type     | Required | Default | Description                              |
|-------------|----------|----------|---------|------------------------------------------|
| `page`      | `number` | No       | `1`     | Page number                              |
| `limit`     | `number` | No       | `10`    | Number of records per page               |
| `search`    | `string` | No       | —       | Search by event title                    |
| `dateFrom`  | `string` | No       | —       | Filter events from this date (ISO 8601)  |
| `dateTo`    | `string` | No       | —       | Filter events up to this date (ISO 8601) |

**Example Request**

```
GET /api/diary-events?page=1&limit=10&search=workshop&dateFrom=2026-01-01&dateTo=2026-06-30
```

**Success Response — `200 OK`**

```json
{
  "data": [
    {
      "id": 1,
      "title": "SME Workshop — Colombo",
      "description": "Quarterly SME onboarding workshop for Western Province.",
      "eventDate": "2026-04-20T00:00:00.000Z",
      "eventTime": "09:00",
      "color": "#3B82F6",
      "createdById": "200012345678",
      "createdAt": "2026-04-15T08:00:00.000Z",
      "updatedAt": "2026-04-15T08:00:00.000Z",
      "rowVersion": 1
    }
  ],
  "meta": {
    "total": 1,
    "page": 1,
    "limit": 10,
    "totalPages": 1
  }
}
```

---

### 2. Get Diary Event by ID

Retrieves a single diary event along with its attachments.

```
GET /api/diary-events/:id
```

**Path Parameters**

| Parameter | Type     | Required | Description              |
|-----------|----------|----------|--------------------------|
| `id`      | `number` | Yes      | ID of the diary event    |

**Success Response — `200 OK`**

```json
{
  "id": 1,
  "title": "SME Workshop — Colombo",
  "description": "Quarterly SME onboarding workshop for Western Province.",
  "eventDate": "2026-04-20T00:00:00.000Z",
  "eventTime": "09:00",
  "color": "#3B82F6",
  "createdById": "200012345678",
  "createdAt": "2026-04-15T08:00:00.000Z",
  "updatedAt": "2026-04-15T08:00:00.000Z",
  "rowVersion": 1,
  "attachments": [
    {
      "id": 1,
      "fileName": "agenda.pdf",
      "fileUrl": "/uploads/diary/agenda.pdf",
      "mimeType": "application/pdf",
      "fileSizeKb": 204,
      "uploadedAt": "2026-04-15T08:05:00.000Z"
    }
  ]
}
```

**Error Responses**

| Status | Code              | Description                        |
|--------|-------------------|------------------------------------|
| `404`  | `EVENT_NOT_FOUND` | No diary event found with that ID  |

---

### 3. Create Diary Event

Creates a new diary event. The `createdById` is automatically set from the authenticated user's session.

```
POST /api/diary-events
```

**Request Body**

```json
{
  "title": "SME Workshop — Colombo",
  "description": "Quarterly SME onboarding workshop for Western Province.",
  "eventDate": "2026-04-20",
  "eventTime": "09:00",
  "color": "#3B82F6"
}
```

**Field Rules**

| Field         | Type     | Required | Validation                                          |
|---------------|----------|----------|-----------------------------------------------------|
| `title`       | `string` | Yes      | Max 200 characters                                  |
| `description` | `string` | No       | Max 1000 characters                                 |
| `eventDate`   | `string` | Yes      | Must be a valid ISO 8601 date (`YYYY-MM-DD`)        |
| `eventTime`   | `string` | Yes      | Max 10 characters — format `HH:mm` recommended     |
| `color`       | `string` | No       | Must be a valid hex colour (e.g. `#3B82F6`). Defaults to `#3B82F6` |

**Success Response — `201 Created`**

```json
{
  "id": 2,
  "title": "SME Workshop — Colombo",
  "description": "Quarterly SME onboarding workshop for Western Province.",
  "eventDate": "2026-04-20T00:00:00.000Z",
  "eventTime": "09:00",
  "color": "#3B82F6",
  "createdById": "200012345678",
  "createdAt": "2026-04-15T10:00:00.000Z",
  "updatedAt": "2026-04-15T10:00:00.000Z",
  "rowVersion": 1
}
```

**Error Responses**

| Status | Code               | Description                              |
|--------|--------------------|------------------------------------------|
| `400`  | `VALIDATION_ERROR` | One or more required fields are missing or invalid |

---

### 4. Update Diary Event

Updates an existing diary event. `rowVersion` must be included and must match the current version in the database (optimistic concurrency control).

```
PUT /api/diary-events/:id
```

**Path Parameters**

| Parameter | Type     | Required | Description           |
|-----------|----------|----------|-----------------------|
| `id`      | `number` | Yes      | ID of the diary event |

**Request Body**

```json
{
  "title": "SME Workshop — Colombo (Updated)",
  "description": "Rescheduled to 10:00 AM.",
  "eventDate": "2026-04-21",
  "eventTime": "10:00",
  "color": "#10B981",
  "rowVersion": 1
}
```

**Field Rules**

| Field         | Type     | Required | Validation                              |
|---------------|----------|----------|-----------------------------------------|
| `title`       | `string` | No       | Max 200 characters                      |
| `description` | `string` | No       | Max 1000 characters                     |
| `eventDate`   | `string` | No       | Valid ISO 8601 date                     |
| `eventTime`   | `string` | No       | Max 10 characters                       |
| `color`       | `string` | No       | Valid hex colour                        |
| `rowVersion`  | `number` | **Yes**  | Must match current `rowVersion` in DB   |

**Success Response — `200 OK`**

```json
{
  "id": 2,
  "title": "SME Workshop — Colombo (Updated)",
  "description": "Rescheduled to 10:00 AM.",
  "eventDate": "2026-04-21T00:00:00.000Z",
  "eventTime": "10:00",
  "color": "#10B981",
  "createdById": "200012345678",
  "createdAt": "2026-04-15T10:00:00.000Z",
  "updatedAt": "2026-04-15T11:30:00.000Z",
  "rowVersion": 2
}
```

**Error Responses**

| Status | Code                 | Description                                              |
|--------|----------------------|----------------------------------------------------------|
| `404`  | `EVENT_NOT_FOUND`    | No diary event found with that ID                        |
| `409`  | `VERSION_CONFLICT`   | `rowVersion` mismatch — record was modified by another user |
| `400`  | `VALIDATION_ERROR`   | `rowVersion` missing or fields fail validation           |

---

### 5. Delete Diary Event

Deletes a diary event and cascades the deletion to all related `DiaryAttachment` records.

```
DELETE /api/diary-events/:id
```

**Path Parameters**

| Parameter | Type     | Required | Description           |
|-----------|----------|----------|-----------------------|
| `id`      | `number` | Yes      | ID of the diary event |

**Success Response — `200 OK`**

```json
{
  "message": "Diary event deleted successfully."
}
```

**Error Responses**

| Status | Code              | Description                       |
|--------|-------------------|-----------------------------------|
| `404`  | `EVENT_NOT_FOUND` | No diary event found with that ID |

---

## Notes

- `createdById` is set automatically from the authenticated session. It is **not** accepted in the request body.
- Deleting a `DiaryEvent` will automatically delete all its `DiaryAttachment` records (cascade delete).
- `rowVersion` starts at `1` on creation and increments by `1` on every successful update.
- `eventTime` is stored as a plain string. The recommended format is `HH:mm` (24-hour), but this is not enforced at the database level — validation should be applied at the DTO layer.
# Participants Module — API Documentation

**Base URL:** `http://localhost:3000/api`  
**Module Path:** `/participants`  
**Last Updated:** April 2026

---

## Overview

The Participants module manages business participants registered in the IDB Training & Development Analytics Platform. A participant represents a business entity (and its owner) that can be enrolled in training programs. All endpoints in this module require the user to be authenticated via an HTTP-only cookie set at login.

---

## Participant Object

This is the standard Participant object returned by most endpoints in this module.

| Field              | Type       | Description                                          |
|--------------------|------------|------------------------------------------------------|
| id                 | integer    | Auto-incremented unique identifier                   |
| businessName       | string     | Registered business name (max 200 characters)        |
| ownerName          | string     | Full name of the business owner (max 100 characters) |
| email              | string     | Unique email address (max 150 characters)            |
| phone              | string     | Contact phone number (max 15 characters)             |
| district           | District   | District where the business is located               |
| sector             | string     | Business sector / industry (max 100 characters)      |
| registrationNumber | string     | Unique business registration number (max 100 chars)  |
| status             | UserStatus | Account status: `active` or `inactive`               |
| rowVersion         | integer    | Used for optimistic concurrency control              |
| createdAt          | datetime   | Timestamp when the record was created (ISO 8601)     |
| updatedAt          | datetime   | Timestamp of the last update (ISO 8601)              |

---

## Enums

### UserStatus

| Value    | Description               |
|----------|---------------------------|
| active   | Participant is active      |
| inactive | Participant is deactivated |

### District

Valid district values: `Colombo`, `Gampaha`, `Kurunegala`, `Kandy`, `Matale`, `Nuwara_Eliya`, `Galle`, `Matara`, `Hambantota`, `Ampara`, `Trincomalee`, `Batticaloa`, `Mullaitivu`, `Puttalam`, `Anuradhapura`, `Polonnaruwa`, `Badulla`, `Monaragala`, `Ratnapura`, `Kegalle`, `Jaffna`, `Kilinochchi`, `Mannar`, `Vavuniya`

---

## Endpoints

---

### GET /participants

Returns a paginated list of all participants.

**Authentication required:** Yes

**Query Parameters:**

| Parameter | Type    | Required | Default | Description                                        |
|-----------|---------|----------|---------|----------------------------------------------------|
| page      | integer | No       | 1       | Page number                                        |
| limit     | integer | No       | 10      | Number of results per page                         |
| search    | string  | No       | —       | Filter by businessName, ownerName, or email        |
| district  | string  | No       | —       | Filter by District                                 |
| sector    | string  | No       | —       | Filter by business sector                          |
| status    | string  | No       | —       | Filter by status (`active` or `inactive`)          |

**Example Request:**

```
GET /api/participants?page=1&limit=10&district=Colombo&status=active
```

**Example Success Response — `200 OK`:**

```json
{
  "data": [
    {
      "id": 1,
      "businessName": "Perera Textiles Pvt Ltd",
      "ownerName": "Chaminda Perera",
      "email": "chaminda@pereratextiles.lk",
      "phone": "0112345678",
      "district": "Colombo",
      "sector": "Manufacturing",
      "registrationNumber": "PV00123456",
      "status": "active",
      "rowVersion": 1,
      "createdAt": "2026-01-10T08:00:00.000Z",
      "updatedAt": "2026-03-05T12:00:00.000Z"
    },
    {
      "id": 2,
      "businessName": "Silva Agro Exports",
      "ownerName": "Ruwan Silva",
      "email": "ruwan@silvaagro.lk",
      "phone": "0117654321",
      "district": "Colombo",
      "sector": "Agriculture",
      "registrationNumber": "PV00789012",
      "status": "active",
      "rowVersion": 1,
      "createdAt": "2026-01-15T09:30:00.000Z",
      "updatedAt": "2026-02-20T14:00:00.000Z"
    }
  ],
  "meta": {
    "total": 120,
    "page": 1,
    "limit": 10,
    "totalPages": 12
  }
}
```

**Possible Errors:**

| Status | Message      | Reason                             |
|--------|--------------|------------------------------------|
| 401    | Unauthorized | Not authenticated / cookie expired |

---

### GET /participants/:id

Returns a single participant by their ID.

**Authentication required:** Yes

**Path Parameters:**

| Parameter | Type    | Required | Description           |
|-----------|---------|----------|-----------------------|
| id        | integer | Yes      | The participant's ID  |

**Example Request:**

```
GET /api/participants/1
```

**Example Success Response — `200 OK`:**

```json
{
  "id": 1,
  "businessName": "Perera Textiles Pvt Ltd",
  "ownerName": "Chaminda Perera",
  "email": "chaminda@pereratextiles.lk",
  "phone": "0112345678",
  "district": "Colombo",
  "sector": "Manufacturing",
  "registrationNumber": "PV00123456",
  "status": "active",
  "rowVersion": 1,
  "createdAt": "2026-01-10T08:00:00.000Z",
  "updatedAt": "2026-03-05T12:00:00.000Z"
}
```

**Possible Errors:**

| Status | Message               | Reason                              |
|--------|-----------------------|-------------------------------------|
| 401    | Unauthorized          | Not authenticated / cookie expired  |
| 404    | Participant not found | No participant exists with that ID  |

---

### POST /participants

Creates a new participant record.

**Authentication required:** Yes

**Request Body:**

| Field              | Type      | Required | Description                                      |
|--------------------|-----------|----------|--------------------------------------------------|
| businessName       | string    | Yes      | Registered business name (max 200 characters)    |
| ownerName          | string    | Yes      | Full name of the business owner (max 100 chars)  |
| email              | string    | Yes      | Unique email address (max 150 characters)        |
| phone              | string    | Yes      | Contact phone number (max 15 characters)         |
| district           | District  | Yes      | District where the business is located           |
| sector             | string    | Yes      | Business sector / industry (max 100 characters)  |
| registrationNumber | string    | Yes      | Unique business registration number              |
| status             | UserStatus| No       | Defaults to `active` if not provided             |

**Example Request:**

```json
{
  "businessName": "Fernando Spices Pvt Ltd",
  "ownerName": "Lasantha Fernando",
  "email": "lasantha@fernandospices.lk",
  "phone": "0812233445",
  "district": "Kandy",
  "sector": "Food & Beverage",
  "registrationNumber": "PV00345678"
}
```

**Example Success Response — `201 Created`:**

```json
{
  "id": 121,
  "businessName": "Fernando Spices Pvt Ltd",
  "ownerName": "Lasantha Fernando",
  "email": "lasantha@fernandospices.lk",
  "phone": "0812233445",
  "district": "Kandy",
  "sector": "Food & Beverage",
  "registrationNumber": "PV00345678",
  "status": "active",
  "rowVersion": 1,
  "createdAt": "2026-04-07T08:00:00.000Z",
  "updatedAt": "2026-04-07T08:00:00.000Z"
}
```

**Possible Errors:**

| Status | Message                          | Reason                                        |
|--------|----------------------------------|-----------------------------------------------|
| 400    | Validation failed                | Missing required fields or invalid values     |
| 401    | Unauthorized                     | Not authenticated / cookie expired            |
| 409    | Email already exists             | Another participant is using this email       |
| 409    | Registration number already exists | This registration number is already recorded |

---

### PUT /participants/:id

Updates an existing participant's details. Requires `rowVersion` for optimistic concurrency control.

**Authentication required:** Yes

**Path Parameters:**

| Parameter | Type    | Required | Description          |
|-----------|---------|----------|----------------------|
| id        | integer | Yes      | The participant's ID |

**Request Body:**

| Field              | Type      | Required | Description                                              |
|--------------------|-----------|----------|----------------------------------------------------------|
| rowVersion         | integer   | Yes      | Must match the current rowVersion stored in the database |
| businessName       | string    | No       | Updated business name                                    |
| ownerName          | string    | No       | Updated owner name                                       |
| email              | string    | No       | Updated email address                                    |
| phone              | string    | No       | Updated phone number                                     |
| district           | District  | No       | Updated district                                         |
| sector             | string    | No       | Updated sector                                           |
| registrationNumber | string    | No       | Updated registration number                              |
| status             | UserStatus| No       | Updated status                                           |

> **Important:** `rowVersion` is mandatory. If the value sent does not match what is currently stored in the database, the update will be rejected with a `409 Conflict` error. Always use the `rowVersion` from the most recent GET response.

**Example Request:**

```json
{
  "rowVersion": 1,
  "phone": "0812299000",
  "status": "inactive"
}
```

**Example Success Response — `200 OK`:**

```json
{
  "id": 121,
  "businessName": "Fernando Spices Pvt Ltd",
  "ownerName": "Lasantha Fernando",
  "email": "lasantha@fernandospices.lk",
  "phone": "0812299000",
  "district": "Kandy",
  "sector": "Food & Beverage",
  "registrationNumber": "PV00345678",
  "status": "inactive",
  "rowVersion": 2,
  "createdAt": "2026-04-07T08:00:00.000Z",
  "updatedAt": "2026-04-07T09:15:00.000Z"
}
```

> **Note:** `rowVersion` increments by 1 after every successful update. Use the new value in any subsequent PUT request.

**Possible Errors:**

| Status | Message               | Reason                                                   |
|--------|-----------------------|----------------------------------------------------------|
| 400    | Validation failed     | Invalid field values                                     |
| 401    | Unauthorized          | Not authenticated / cookie expired                       |
| 404    | Participant not found | No participant exists with that ID                       |
| 409    | Conflict              | rowVersion mismatch — record was updated by someone else |

---

### DELETE /participants/:id

Permanently deletes a participant record.

**Authentication required:** Yes

**Path Parameters:**

| Parameter | Type    | Required | Description          |
|-----------|---------|----------|----------------------|
| id        | integer | Yes      | The participant's ID |

**Example Request:**

```
DELETE /api/participants/121
```

**Example Success Response — `200 OK`:**

```json
{
  "message": "Participant deleted successfully"
}
```

**Possible Errors:**

| Status | Message               | Reason                              |
|--------|-----------------------|-------------------------------------|
| 401    | Unauthorized          | Not authenticated / cookie expired  |
| 404    | Participant not found | No participant exists with that ID  |

---

## Summary Table

| Method | Endpoint              | Description               | Auth Required |
|--------|-----------------------|---------------------------|---------------|
| GET    | /api/participants     | List all participants     | Yes           |
| GET    | /api/participants/:id | Get a single participant  | Yes           |
| POST   | /api/participants     | Create a new participant  | Yes           |
| PUT    | /api/participants/:id | Update a participant      | Yes           |
| DELETE | /api/participants/:id | Delete a participant      | Yes           |
# IDB Training and Development Analytics Platform - Program Enrollement Module


**Version:** 1.0
**Last Update:** April 2026
**Team:** Backend
**Base URL:** 'http://localhost:3000/'ProgramEnrolAPI'
**Base Path:**  /api/enrollments


---

## 1.Introduction

The Program Enrollement module handles the relationship between the SME participants and their taining programs that they've enrolled. This module also tracks their progress and the current enrollment state throughout the program.
Each enrollemnt links a SME to their training program, and the IDB staff ahs the ability to change their enrollement status as progress, completed and withdrawn.

---


## 2. Program Enrollement Object

The following are the standard objects returned by the endpoints in this module.

|       Field Name      |           Type             |           Description                                                                      |
|-----------------------|----------------------------|--------------------------------------------------------------------------------------------|
|           id          |          Integer           |   Auto Increment Unique Identifier                                                         |
|      ProgramId        |          Integer           |   This is a FK of the Program table                                                        |
|       Program         |      Training Program      |   The full trianing program object linked to this enrollement - included when requested    |
|     ParticipantId     |          Integer           |   Id of the enrollemnt participant                                                         |
|    EnrollementDate    |        datetime            |   Date and Time of enrollment                                                              |
|    completionStatus   |      ComplettionStatus     |   Current Status of enrollment(see enums)                                                  |
|      ticketPrice      |       decimal              |   fee charged for enrollment                                                               |
|     rowVersion        |       Integer              |   USed for optimistic concurrency control                                                  | 
|      createdAt        |       datetime             |   Timestamp when the record was created                                                    | 
|      updatedAt        |       datetime             |   timestamp when the record was updated                                                    |

---

## enum

### CompletionStatus

|           Value           |           Description                                                        |
|     ProgramStatus         |  Whether is the SME is enrolled, has completed or dropped the program        |


---

## EndPoints

### GET/enrollments

Gets a pagianted list of all the enrolled records.

**Authentication Required:** Yes

**Allowed Roles:** System Admin, Epo_do, Ma_Clerk, ad_dd, hod_manager, Board_chairman

**Query Parameters**

|       Parameter       |       Type           |        Required        |       Default         |             Description                          |
|-----------------------|----------------------|------------------------|-----------------------|--------------------------------------------------|
|       Page            |       Integer        |          No            |          1            |              Page  Number                        |
|       Limit           |       Integer        |          No            |         10            |    number of results per page                    |
|     ProgramId         |       Integer        |          No            |         -             |       Filter by program                          |
|     ParticipantId     |       Integer        |          No            |         -             |       Filter by participant                      |
|    CompletionStatus   |        String        |          No            |         -             |   Filter by enrolled, completed, or dropped      |

**Example Request**

```
GET /api/enrollments?page=1&1limit=10
```

**Example Success Response:** 200 OK

**Possible Errors**

|       Status          |               Message             |                Reason                                             |
|-----------------------|-----------------------------------|-------------------------------------------------------------------|
|        401            |            Unauthorized           |    No cookie present or token expired                             |
|        403            |            Forbidden              |    Authenticated but role is not allowed to access this end point |

### GET/enrollment/:id

This returns a single enrollment record by its ID. This is Used when the frontend needs to display the details of one specific enrollment.

**Authentication Required:** Yes

**Allowed Roles:** System Admin, Epo_do, Ma_Clerk, ad_dd, hod_manager, Board_chairman

**Query Parameter**

|       Parameter       |       Type           |        Required        |       Default         |             Description                          |
|-----------------------|----------------------|------------------------|-----------------------|--------------------------------------------------|
|          id           |       Integer        |          YES           |          1            |             The enrollment's ID                  |

**Example Request**

```
GET /api/enrollments/5

```

**Example Success Response:** 200 OK

**Possible Errors**

|       Status          |               Message             |                Reason                                             |
|-----------------------|-----------------------------------|-------------------------------------------------------------------|
|        401            |            Unauthorized           |    No cookie present or token expired                             |
|        403            |            Forbidden              |    Authenticated but role is not allowed to access this end point |
|        404            |       Enrollment not Found        |    No Enrollment exists with the given ID                         |


### POST/enrollments

This creates a new enrollment , by linking a participant to training program

**Authentication Required:** Yes

**Allowed Roles:** System_admin, epo_do, ma_clerk

**Query Parameters:**

|       Feild       |       Type        |       Required        |                      Description                     |
|-------------------|-------------------|-----------------------|------------------------------------------------------|
|       programId   |      Integer      |        Yes            |               Id of the trianing program             |
|   ParticipantId   |      Integer      |        Yes            |               Id of the participant                  |
|  completionStatus |      string       |        No             |                 Defaults to enrolled                 |
|   ticketPrice     |      decimal      |         No            | Required if program type is ticketed, null if free   | 

**Example Request:**

```json
{
    "status": true,
    "message": "Retrieved n number of enrollment successfully",
    "timestamp": "2026-01-05 05:15:45",
    "data":{
        "programId": 3,
        "participantId": 12,
        "ticketPrice": 1500.00
    }
    "meta":{
        "total": 20,
        "page": 1,
        "limmit": 10,
        "totalPages":2
    }
}
```

**Example Success Response :** 201 Created


```json
{
    "status": true,
    "message": "Retrieved n number of enrollment successfully",
    "timestamp": "2026-01-05 05:15:45",
    "data":{
        "id": 1,
        "programId": 3,
        "participantId": 12,
        "enrollmentDate": "2026-04-08T08:30:00.000Z",
        "completionStatus": "enrolled",
        "ticketPrice": 1500.00,
        "rowVersion": 1,
        "createdAt": "2026-04-08T08:30:00.000Z",
        "updatedAt": "2026-04-08T08:30:00.000Z"
    }
    "meta":{
        "total": 20,
        "page": 1,
        "limmit": 10,
        "totalPages":2
    }
}
```

**Possible Errors**

|       Status          |               Message             |                Reason                                             |
|-----------------------|-----------------------------------|-------------------------------------------------------------------|
|        400            |       Validation Failed           |    Missing or invalid field                                       |
|        401            |            Unauthorized           |    No cookie present or token expired                             |
|        403            |            Forbidden              |    Authenticated but role is not allowed to access this end point |
|        404            |          Program not Found        |    No Program exists with the given ID                            |
|        404            |       Participant not Found       |    No Participant exists with the given ID                        |
|        404            |       Enrollment already exist    |    This participant is already enrolled in this program           |


### PUT/enrollments/:id

This endpoint updates an existing enrollemnt record.

**Authentication Required:** Yes

**Allowed Roles:** system_admin, epo_do, ma_clerk

**Query Parameters**

|       Feild       |       Type        |       Required        |                      Description                     |
|-------------------|-------------------|-----------------------|------------------------------------------------------|
|       Id          |      Integer      |        Yes            |           The Enrollment's ID       |


**Example Request:**

```json
{
    "status": true,
    "message": "Retrieved n number of enrollment successfully",
    "timestamp": "2026-01-05 05:15:45",
    "data":{
        "completionStatus": "completed",
        "rowVersion": 1
    }
    "meta":{
        "total": 20,
        "page": 1,
        "limmit": 10,
        "totalPages":2
    }
}
```

**Example Success Response :** 200 OK


```json
{
    "status": true,
    "message": "Retrieved n number of enrollment successfully",
    "timestamp": "2026-01-05 05:15:45",
    "data":{
        "id": 1,
        "programId": 3,
        "participantId": 12,
        "enrollmentDate": "2026-04-08T08:30:00.000Z",
        "completionStatus": "Created",
        "ticketPrice": 1500.00,
        "rowVersion": 2,
        "createdAt": "2026-04-08T08:30:00.000Z",
        "updatedAt": "2026-04-08T08:30:00.000Z"
    }
    "meta":{
        "total": 20,
        "page": 1,
        "limmit": 10,
        "totalPages":2
    }
}
```

**Possible Errors**

|       Status          |               Message             |                Reason                                             |
|-----------------------|-----------------------------------|-------------------------------------------------------------------|
|        400            |       Validation Failed           |    Missing or invalid field                                       |
|        401            |            Unauthorized           |    No cookie present or token expired                             |
|        403            |            Forbidden              |    Authenticated but role is not allowed to access this end point |
|        404            |          Enrollment not Found        |    No Enrollment exists with the given ID                            |
|        422            |   Record has been modified by another user    |    rowVersion Mismatch       |


### DElETE/enrollments/:id

This endpoint is used to permenantly delete an enrollment record.

**Authentication Required:** Yes

**Allowed Roles:** system_admin

**Query Parameters**

|       Feild       |       Type        |       Required        |                      Description                     |
|-------------------|-------------------|-----------------------|------------------------------------------------------|
|       Id          |      Integer      |        Yes            |           The Enrollment's ID       |


**Example Request:**

DELETE /api/enrollments/1

```json
{
    "status": true,
    "message": "Retrieved n number of enrollment successfully",
    "timestamp": "2026-01-05 05:15:45",
    "data":{
        "completionStatus": "completed",
        "rowVersion": 1
    }
    "meta":{
        "total": 20,
        "page": 1,
        "limmit": 10,
        "totalPages":2
    }
}
```

**Example Success Response :** 200 OK


```json
{
    "status": true,
    "message": "Retrieved n number of enrollment successfully",
    "timestamp": "2026-01-05 05:15:45",
    "data":{
        "id": 1,
        "programId": 3,
        "participantId": 12,
        "enrollmentDate": "2026-04-08T08:30:00.000Z",
        "completionStatus": "Created",
        "ticketPrice": 1500.00,
        "rowVersion": 2,
        "createdAt": "2026-04-08T08:30:00.000Z",
        "updatedAt": "2026-04-08T08:30:00.000Z"
    }
    "meta":{
        "total": 20,
        "page": 1,
        "limmit": 10,
        "totalPages":2
    }
}
```

**Possible Errors**

|       Status          |               Message             |                Reason                                             |
|-----------------------|-----------------------------------|-------------------------------------------------------------------|
|        401            |            Unauthorized           |    No cookie present or token expired                             |
|        403            |            Forbidden              |    Authenticated but role is not allowed to access this end point |
|        404            |          Enrollment not Found        |    No Enrollment exists with the given ID                            |


## Summary Table

| Method |    Endpoint          | Description              | Auth Required |   Allowed Roles                |
|--------|----------------------|--------------------------|---------------|--------------------------------|
|   GET  | /api/enrollments     |List all enrollments      |     Yes       |      All roles                 |
|   GET  | /api/enrollments/:id | Get a single enrollment  |     Yes       |      All roles                 |
|   POST | /api/enrollments     |Create a new enrollment   |     Yes       | system_admin, epo_do, ma_clerk |
|   PUT  | /api/enrollments/:id |Update an enrollment      |     Yes       | system_admin, epo_do, ma_clerk | 
|  DELETE| /api/enrollments/:id |Delete an enrollment      |     Yes       | system_admin                   |

---

## Training Programs API

**Base path (relative to [Base URL](#2-base-url)):** `/programs`  
**Example (development):** `http://localhost:3000/api/programs`

### Overview

The Training Programs API is responsible for managing all training-related operations within the IDB Training Management and Analytics Platform.

This API enables the system to:

- Create and manage training programs
- Track program details such as location, capacity, and cost
- Provide filtered views of programs for analytics and reporting
- Support participant enrollment workflows (linked with the enrollment API)

This module acts as the core operational layer for training management.

### Standard response format

All responses follow a consistent envelope:

```json
{
  "success": true,
  "message": "Operation successful",
  "data": {},
  "meta": {}
}
```

### Endpoints

#### GET /programs

Retrieves a list of all training programs with support for filtering, searching, and pagination.

**Query parameters**

| Parameter | Type   | Description                                |
| --------- | ------ | ------------------------------------------ |
| page      | number | Page number (default: 1)                   |
| limit     | number | Items per page (default: 10)               |
| province  | string | Filter by province                         |
| district  | string | Filter by district                         |
| mode      | string | Online / Physical                          |
| status    | string | Scheduled / Active / Completed / Cancelled |

**Example response**

```json
{
  "success": true,
  "message": "Programs retrieved successfully",
  "data": [
    {
      "id": 1,
      "name": "Entrepreneurship Training",
      "province": "Western",
      "district": "Colombo",
      "fee": 5000,
      "capacity": 50,
      "mode": "Physical",
      "status": "Active"
    }
  ],
  "meta": {
    "page": 1,
    "limit": 10,
    "total": 100,
    "totalPages": 10
  }
}
```

**Typical usage**

- Dashboard program listing
- Filtering programs by region or type
- Analytics and reporting views

---

#### POST /programs

Creates a new training program in the system.

**Request body**

```json
{
  "name": "Advanced Business Training",
  "province": "Southern",
  "district": "Galle",
  "fee": 7000,
  "capacity": 40,
  "mode": "Online"
}
```

**Example response**

```json
{
  "success": true,
  "message": "Program created successfully",
  "data": {
    "id": 2,
    "name": "Advanced Business Training",
    "status": "Scheduled"
  }
}
```

**Typical usage**

- Program managers create new training sessions
- Initial step before participant enrollment

---

#### PUT /programs/:id

Updates an existing training program’s details.

**Request body**

```json
{
  "name": "Updated Training Program",
  "fee": 6500,
  "capacity": 60,
  "status": "Active"
}
```

**Example response**

```json
{
  "success": true,
  "message": "Program updated successfully"
}
```

**Typical usage**

- Modify training details
- Update program status (Scheduled → Active → Completed)

---

#### DELETE /programs/:id

Deletes a training program from the system.

**Example response**

```json
{
  "success": true,
  "message": "Program deleted successfully"
}
```

**Typical usage**

- Remove cancelled or invalid programs

---

#### GET /programs/:id

Fetches detailed information about a specific training program.

**Typical usage**

- Viewing full program details
- Linking with participant list and analytics

---

### Business logic and validation

**Validation rules**

| Field    | Rule |
| -------- | ---- |
| name     | Required; max 100 characters |
| province | Must be a valid Sri Lankan province |
| district | Must match selected province |
| fee      | Must be ≥ 0 |
| capacity | Must be > 0 and ≤ 500 |
| mode     | Must be either Online or Physical |

**Business rules**

- Default program status: **Scheduled**
- Status lifecycle: **Scheduled** → **Active** → **Completed** or **Cancelled**
- A program should not be deleted if participants are enrolled (recommended)
- Capacity must not be exceeded during enrollment

---

### Role in the system

The Training Programs API is critical because it:

- Acts as the foundation for participant enrollment
- Drives analytics dashboards
- Supports geographic and performance insights
- Enables program lifecycle management

Without this API: no programs → no participants → no analytics → no system.

---

### Summary table

| Method | Endpoint           | Description              |
| ------ | ------------------ | ------------------------ |
| GET    | /api/programs      | List programs (paginated) |
| GET    | /api/programs/:id | Get one program          |
| POST   | /api/programs      | Create program           |
| PUT    | /api/programs/:id | Update program           |
| DELETE | /api/programs/:id | Delete program           |
