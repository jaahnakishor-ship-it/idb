# IDB Training and Development Analytics Paltform - API Documentation


**Version:** 1.0
**Last Update:** April 2026
**Team:** Backend (Problem 1)
**Base URL:** 'http://localhost:3000/api'

--

## 1. Introduction

This document describes all the REST API endpoints exposed by the IDB Training and Development Analytics Paltform backend.

The API is consumed by the React.JS frontend and is responsible for:

- User and Participant management
- Trianing Program Management
- Program enrollement Tracking
- Digital Diary and Field notes
- Analytics and Reporting

All request and response bodies use **JSON format** unless stated otherwise.

All endpoint require the user to be **authenticated** via an HTTP-only cookie set at login. Unauthorized login will recieve a  '401 Unauthorized' response.

--

## 2. Base URL


|  Environment  |            URL               |

|  Development  | 'http://localhost:3000/api'  |
|  Production   |  TBD                         |


All endpoint paths in this document are relative to the base URL.
for example,  'GET/Users'  means 'GET http://localhost:3000/api/users'

--


## 3. Authentication

This API uses **JWT tockens stored in HTTP-only cookies** for authentification. The frontend does not need to manually attach any token requests - The browser handles the cookie automatically.

---

### POST/auth/login

Authenticates a user and sets an HTTP-only cookie containing the JWT token.

**Authentication required:** No

**Request Body:**

|      Feild        |       Type        |       Required        |       Description     |
|-------------------|-------------------|-----------------------|-----------------------|
|       email       |       String      |       Yes             |     User's Email      |
|     Password      |       String      |       Yes             |  User's Password      |

**Example Request:**

```json
{
    "email": "zainab@idb.gov.lk",
    "Password": "Securepassword123"
}
```

**Example Success Response - '200 OK' :**

```json
{
    "Message": "Login Successful",
    "User": {
        "NIC": "200057803262",
        "name": "Zainab Rikaz",
        "email": "zainab@idb.gov.lk",
        "role": "system_admin",
        "district": null,
        "status": "active"
    }
}
```

**Note:** The JWT Token is NOT returned in the response body.It is set automatically as an HTTP-only Cookie named `access token`.

**Possible Errors:**

|       Status      |         Message       |               Reason          |
|-------------------|-----------------------|-------------------------------|
|       400         |   Validation Failed   |   Missing email or password   |
|       401         |   Invalid Credentials |   Wrong email or Password     |


---


### POST/auth/Logout

clears the authentification cookie and ends the session.

**Authentication Required:** Yes

**Request Body:** None

**Example Success Response - `200 OK`:**
```json
{
    "message": "Logged out successfully"
}
```

---

### GET /auth/me 

Return the currently authenticated user's profile based on the cookie.

**Authentication required:** Yes

**Request Body:** None

**Example Success REsponse - `200 OK` :**
```json

{
    "NIC": "2000185231",
    "name": "Zainab Rikaz",
    "email": "zainab@idb.gov.lk",
    "role": "system_admin",
    "district": null,
    "status": "active",
    "createdAt": "2026-01-15T08:30:00.000Z",
    "updatedAt": "2026-03-01T10:00:00.000Z"
}
```

**Possible Errors:**

|       Status      |       Message     |       Reason                      |
|-------------------|-------------------|-----------------------------------|
|      401          |    Unauthorized   |     No Cookie or Token Expired    |


---

## 4. Error Format

All response from the API follow a consistent JSON structure.

**Example Error Response:**
```json

{
    "statusCode": 404,
    "message": "User not found",
    "error" : "Not Found"

}
```

---

### Standard HTTP Status Codes used in this API

| Status Code | Meaning               | When It Occurs                                      |
|-------------|-----------------------|-----------------------------------------------------|
|    200      |       OK              |    Request succeeded                                |
|    201      |     Created           |   New Record Successfuly created                    |
|    400      |    Bad REquest        |  Missing or invalid feilds in the request body      |
|    401      |    Unauthorized       |  No cookie present or JWT token expired             |
|    403      |    Forbidden          |  Authenticated but not allowed to perform the action|
|    404      |   Not Found           |  Requested REcord doesnot exist                     |
|    409      |   Conflict            |   Duplicate Entry (e.g. email or NIC already exist) |
|    422      |  Unprocessable Entry  |  Row version Mismatch - optimmistic concurrency     |
|    500      | Internal Server Error |   Unexpected Server Side Error                      |      


## 5. Pagination, Search and Filter

All `GET` list endpoints support pagination, search, and filtering via query parameters.

**Example:**

GET/api/users?page=1&limit=10&search=zainab&role-System_administrator&status=active

###Query Parameters

| Parameter | Type   | Default | Description                        |
|-----------|--------|---------|------------------------------------|
| page      | number | 1       | Page number                        |
| limit     | number | 10      | Number of records per page         |
| search    | string | —       | Search by name or email            |
| status    | string | —       | Filter by status (active/inactive) |



### Standard Pagination Response Structure

All list endpoints return data in this format:
```json
{
    "data": [],
    "meta": {
        "total": 100,
        "Page": 1,
        "limit": 10,
        "totalPages": 10
    }
}
```

| Field           | Description                              |
|-----------------|------------------------------------------|
| data            | Array of records for the current page    |
| meta.total      | Total number of records in the database  |
| meta.page       | Current page number                      |
| meta.limit      | Records per page                         |
| meta.totalPages | Total number of pages               |

---

## 6. RowVersion - Optimistic Concurrency Control

Every table in the database include a `rowVersion` feild.This  prevents two users from overwriting each other's changes at the same time.


### How it works 

1. Frontend fetches a record - response include `"rowVersion":1`
2. Frontend send a `PUT` request to update -- must include `"rowVersion":1` in the request body.
3. Backend checks if the rowVersion in the request matches the one in the database.
4. If they **match** - Update Proceeds, `"rowVersion"` increments to 2
5. If they **do not match** - request is rejected with `422`


### Rule 

> Every `PUT` request body must include the current `rowVersion`
> of the record being updated. if it is missing or incorrect, 
> the update will be rejected.

### Example Conflict Error - `422 Unprocessable Entity`

```json
{
    "statusCode": 422,
    "message": "Record has been modified by another user.
                Please refresh and try again.",
    "error": "Unprocessable Entity"
} 
```

## 7. Users Module

Base path: `/api/users`

The Users module manages all internal IDB staff accounts. Users are identified by their Sri Lankan NIC number. Which serves as the primary key.

---

### GET /users

Return a paginated list of all users

**Authentication required:** Yes

**Query Parameters:** Supports pagination, search, and filter
(see Section 5)

| Parameter | Type   | Description                  |
|-----------|--------|------------------------------|
| search    | string | Search by name or email      |
| role      | string | Filter by role               |
| status    | string | Filter by status             |
| district  | string | Filter by district           |

**Example Request:**
```
GET /api/users?page=1&limit=10&role=epo_do&district=Colombo
```

**Example Success Response — `200 OK`:**
```json
{
  "data": [
    {
      "NIC": "200187654321",
      "name": "Kamal Perera",
      "email": "kamal@idb.gov.lk",
      "role": "epo_do",
      "district": "Colombo",
      "status": "active",
      "createdAt": "2026-01-15T08:30:00.000Z",
      "updatedAt": "2026-03-01T10:00:00.000Z"
    }
  ],
  "meta": {
    "total": 60,
    "page": 1,
    "limit": 10,
    "totalPages": 6
  }
}
```

---


### GET /users/:NIC

Returns a single user by their NIC number.

**Authentication required:** Yes

**URL Parameter:**

| Parameter | Type   | Description        |
|-----------|--------|--------------------|
| NIC       | string | User's NIC number  |

**Example Request:**
```
GET /api/users/200187654321
```

**Example Success Response — `200 OK`:**
```json
{
  "NIC": "200187654321",
  "name": "Kamal Perera",
  "email": "kamal@idb.gov.lk",
  "role": "epo_do",
  "district": "Colombo",
  "status": "active",
  "rowVersion": 1,
  "createdAt": "2026-01-15T08:30:00.000Z",
  "updatedAt": "2026-03-01T10:00:00.000Z"
}
```

**Possible Errors:**

| Status | Message           | Reason                       |
|--------|-------------------|------------------------------|
| 404    | User not found    | No user with that NIC exists |

---

### POST /users

Creates a new user account.

**Authentication required:** Yes

**Request Body:**

| Field    | Type   | Required | Description                                        |
|----------|--------|----------|----------------------------------------------------|
| NIC      | string | Yes      | Sri Lankan NIC (9 digits + V/X or 12 digits)       |
| name     | string | Yes      | Full name (max 100 characters)                     |
| email    | string | Yes      | Unique email address (max 150 characters)          |
| password | string | Yes      | Plain text password (will be hashed before saving) |
| role     | string | Yes      | One of: `system_admin`, `epo_do`, `ma_clerk`, `ad_dd`, `hod_manager`, `board_chairman` |
| district | string | No       | Required if role is `epo_do`, `ma_clerk`, or `ad_dd` |
| status   | string | No       | `active` or `inactive` — defaults to `active`     |

**Example Request:**
```json
{
  "NIC": "200187654321",
  "name": "Kamal Perera",
  "email": "kamal@idb.gov.lk",
  "password": "securepassword123",
  "role": "epo_do",
  "district": "Colombo",
  "status": "active"
}
```

**Example Success Response — `201 Created`:**
```json
{
  "NIC": "200187654321",
  "name": "Kamal Perera",
  "email": "kamal@idb.gov.lk",
  "role": "epo_do",
  "district": "Colombo",
  "status": "active",
  "rowVersion": 1,
  "createdAt": "2026-04-07T08:30:00.000Z",
  "updatedAt": "2026-04-07T08:30:00.000Z"
}
```

**Note:** `password` is never returned in any response.

**Possible Errors:**

| Status | Message                        | Reason                              |
|--------|--------------------------------|-------------------------------------|
| 400    | Validation failed              | Missing or invalid fields           |
| 409    | Email already exists           | Another user has the same email     |
| 409    | NIC already exists             | Another user has the same NIC       |

---

### PUT /users/:NIC

Updates an existing user's details.

**Authentication required:** Yes

**URL Parameter:**

| Parameter | Type   | Description       |
|-----------|--------|-------------------|
| NIC       | string | User's NIC number |

**Request Body:**

| Field      | Type   | Required | Description                              |
|------------|--------|----------|------------------------------------------|
| name       | string | No       | Updated full name                        |
| email      | string | No       | Updated email address                    |
| role       | string | No       | Updated role                             |
| district   | string | No       | Updated district                         |
| status     | string | No       | Updated status                           |
| rowVersion | number | Yes      | Must match current rowVersion in database|

**Example Request:**
```json
{
  "name": "Kamal Perera",
  "role": "ma_clerk",
  "district": "Gampaha",
  "rowVersion": 1
}
```

**Example Success Response — `200 OK`:**
```json
{
  "NIC": "200187654321",
  "name": "Kamal Perera",
  "email": "kamal@idb.gov.lk",
  "role": "ma_clerk",
  "district": "Gampaha",
  "status": "active",
  "rowVersion": 2,
  "createdAt": "2026-01-15T08:30:00.000Z",
  "updatedAt": "2026-04-07T09:00:00.000Z"
}
```

**Possible Errors:**

| Status | Message                                              | Reason                        |
|--------|------------------------------------------------------|-------------------------------|
| 400    | Validation failed                                    | Invalid fields                |
| 404    | User not found                                       | No user with that NIC exists  |
| 409    | Email already exists                                 | Email belongs to another user |
| 422    | Record has been modified by another user             | rowVersion mismatch           |

--

### DELETE /users/:NIC

Deletes a user account permanently.

**Authentication required:** Yes

**URL Parameter:**

| Parameter | Type   | Description       |
|-----------|--------|-------------------|
| NIC       | string | User's NIC number |

**Example Request:**
```
DELETE /api/users/200187654321
```

**Example Success Response — `200 OK`:**
```json
{
  "message": "User deleted successfully"
}
```

**Possible Errors:**

| Status | Message         | Reason                       |
|--------|-----------------|------------------------------|
| 404    | User not found  | No user with that NIC exists |


