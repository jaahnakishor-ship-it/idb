# Backend Framework Documentation

**Task:** T001 | **Location:** /docs/BACKEND.md | **Version:** 1.0 | **Team:** Backend

---

## 1. Overview

This document describes the planned backend framework, architecture decisions, folder structure, packages, and development guidelines for the IDB Training & Development Analytics Platform.

The backend is responsible for:

- Exposing RESTful API endpoints consumed by the React.js frontend
- Handling authentication and role-based access control (RBAC)
- Managing all business logic — programs, participants, financials, analytics
- Communicating with the PostgreSQL database via Prisma ORM

---

## 2. Technology Stack

| Layer | Technology | Version | Reason |
|---|---|---|---|
| Runtime | Node.js | v22+ | JavaScript runtime, fast, widely used |
| Framework | NestJS | v10+ | Structured, scalable, built-in modules, services, repositories |
| Language | TypeScript | v5+ | Type safety, catches errors at compile time |
| Database | PostgreSQL | v16 | Relational database, best for structured data and analytics |
| ORM | Prisma | v7+ | Type-safe database client, clean migrations, auto-generated client |
| Authentication | JWT + HTTP-only Cookies | --- | Secure token-based auth, cookie prevents XSS attacks |
| Password Hashing | bcryptjs | v2.4+ | Industry standard for hashing passwords before storing |
| Validation | class-validator | --- | Validates incoming request data automatically |
| Containerization | Docker | --- | Consistent environment across all machines |

---

## 3. Why NestJS Over Express

| Feature | Express.js | NestJS |
|---|---|---|
| Structure | Manual — you build it yourself | Built-in modules, controllers, services |
| TypeScript | Optional | Default |
| Repository pattern | Manual setup required | Built-in support |
| Validation | Manual | Built-in with class-validator |
| Fits task T006 | Partially | Perfectly |

NestJS was chosen because T006 explicitly requires models, repositories, services, and APIs as separate layers — NestJS enforces this structure by design.

---

## 4. Layered Architecture

Every feature in the backend follows this strict layered pattern:
```
HTTP Request
    ↓
Controller  →  Handles HTTP request and response
    ↓
Service     →  Contains all business logic
    ↓
Repository  →  Communicates with the database
    ↓
Entity      →  Defines the database table structure
    ↓
PostgreSQL DB  →  Stores the data
```

| Layer | File | Responsibility |
|---|---|---|
| Controller | *.controller.ts | Receives request, calls service, returns response |
| Service | *.service.ts | Business logic, validation rules, calculations |
| Repository | *.repository.ts | Database queries — find, save, update, delete |
| Entity | *.entity.ts | Defines table columns, relationships, constraints |
| Module | *.module.ts | Wires everything together |
| DTO | *.dto.ts | Defines the shape of incoming request data |

---

## 5. Row Version — Optimistic Concurrency Control

Every table in the database must include a row version column. This is mandatory as stated in T006.

### What it is

Row Version is a number that increments by 1 every time a record is updated. Before updating a record, the system checks if the `rowVersion` in the request matches the `rowVersion` in the database. If they do not match, it means someone else has already updated the record and the request is rejected.

### Why it is needed

Prevents two users from overwriting each other's changes at the same time.

### Example
```
User A reads record → rowVersion = 1
User B reads record → rowVersion = 1
User A updates → rowVersion becomes 2 ✅
User B tries to update with rowVersion 1 → REJECTED ❌
```

### Implementation in every entity
```typescript
@VersionColumn()
rowVersion: number;
```

---

## 6. Authentication Flow — HTTP-only Cookies

Authentication uses JWT tokens stored in HTTP-only cookies — not in localStorage or Authorization headers.

1. User sends `POST /api/auth/login` with email and password
2. Backend finds user by email in the database
3. Backend compares entered password with bcrypt hash
4. If match — generate JWT token
5. Return token inside `Set-Cookie` header with `HttpOnly`, `Secure`, `SameSite` flags
6. Browser stores cookie automatically
7. Every subsequent request sends the cookie automatically
8. Auth middleware reads token from cookie and validates it
9. If valid — attach user to request and allow access
10. `POST /api/auth/logout` clears the cookie

| Cookie Flag | Purpose |
|---|---|
| HttpOnly | JavaScript cannot read the cookie — prevents XSS attacks |
| Secure | Cookie only sent over HTTPS |
| SameSite=Strict | Cookie not sent with cross-site requests — prevents CSRF attacks |

---

## 7. API Conventions

### Base URL
```
http://localhost:3000/api
```

### Endpoint Naming
```
GET    /api/users          Get all users (paginated)
GET    /api/users/:id      Get one user
POST   /api/users          Create user
PUT    /api/users/:id      Update user
DELETE /api/users/:id      Delete user

POST   /api/auth/login     Login
POST   /api/auth/logout    Logout
GET    /api/auth/me        Get current user
```

### Pagination, Search and Filter

All GET list endpoints must support pagination, search, and filter as required by T006.
```
GET /api/users?page=1&limit=10&search=zainab&role=admin&status=active
```

| Parameter | Type | Description |
|---|---|---|
| page | number | Page number — default 1 |
| limit | number | Items per page — default 10 |
| search | string | Search by name or email |
| role | string | Filter by role |
| status | string | Filter by status |

---

## 8. Environment Variables

Copy `.env.example` to `.env` and fill in your values. Never commit `.env` to Git.
```env
PORT=3000
NODE_ENV=development
DB_HOST=localhost
DB_PORT=5432
DB_NAME=idb_platform
DB_USER=postgres
DB_PASSWORD=your_password_here
JWT_SECRET=your_super_secret_key_change_this
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

---

## 9. How to Set Up and Run

### Prerequisites

- Node.js v22+
- PostgreSQL v16
- Docker Desktop
- Git

### Steps

1. Clone the repository and go into the backend folder
2. Run: `npm install`
3. Copy `.env.example` to `.env` and fill in your PostgreSQL password and JWT secret
4. Run in development mode: `npm run start:dev`
5. Open browser at `http://localhost:3000` to verify it is running

### Running with Docker
```bash
docker-compose up --build   # start all containers
docker-compose down         # stop all containers
```

---

## 10. Git Workflow

### Branch Structure
```
main                         → production code only
develop                      → main development branch
feature/T006-users-module
feature/T007-auth
```

### Branch Naming
```
feature/<task-id>-<short-description>
fix/<task-id>-<short-description>
```

### Commit Message Convention
```
feat: add user entity with row version
fix: correct password hashing in user service
docs: update backend documentation
test: add unit tests for user service
```

---

*Backend Team — IDB Platform — Version 1.0 — March 2026*